package com.freestylepanel.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final int BG = 0xFF000000, FG = 0xFFFFFFFF, MUTE = 0xFF8E8E8E, GREEN = 0xFF1DD18B, RED = 0xFFE53935;

    // Sensitivity data per DPI tab (No DPI, -600, +600, +1000) x 5 sets x {General, Red Dot, 2x, 4x, AWM}.
    // Values read from the recording are exact; AWM and the sets that never appeared fully on screen are placeholders.
    static final String[] TABS = {"No DPI", "- 600", "+ 600", "+ 1000"};
    static final int[][][] DATA = {
            {{87, 93, 96, 93, 82}, {89, 90, 93, 99, 24}, {86, 92, 94, 94, 31}, {81, 91, 92, 96, 28}, {99, 96, 95, 95, 35}},
            {{76, 94, 91, 98, 25}, {72, 90, 91, 93, 22}, {82, 97, 96, 95, 30}, {84, 93, 92, 96, 27}, {88, 95, 94, 97, 33}},
            {{79, 94, 96, 94, 26}, {70, 95, 98, 98, 23}, {76, 91, 95, 97, 29}, {81, 92, 93, 96, 27}, {85, 94, 95, 98, 31}},
            {{81, 92, 98, 100, 28}, {75, 93, 92, 99, 24}, {73, 100, 93, 97, 21}, {78, 94, 95, 98, 26}, {83, 96, 97, 99, 30}}};
    static final String[] LABELS = {"General", "Red Dot", "2x Scope", "4x Scope", "AWM Scope"};
    static final int[] ICONS = {GlyphView.AIM, GlyphView.AIM_RED, GlyphView.AIM_2X, GlyphView.AIM_4X, GlyphView.AIM_AWM};
    static final float[] FADE = {1f, .8f, .6f, .42f, .26f};

    SharedPreferences sp;
    FrameLayout content;
    View current;
    FrameLayout navPower, navSens;
    GlyphView navPowerG, navSensG;
    int tab = 0, stage = 0, mode = 100, dpiTab = 0, detailSet = 0;

    // start-page widgets
    FrameLayout startBtn, seg0, seg1;
    GlyphView startGlyph, g0, g1;
    TextView segTitle, segDesc, opVal;
    LinearLayout segBox;
    SeekBar opBar;
    View segRow, opRow;

    // ------------------------------------------------------------ helpers
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable shape(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    LinearLayout vl() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new OvershootInterpolator(2.5f)).start();
            return false;
        });
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------ lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("fp", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        LinearLayout root = vl();
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        View line = new View(this);
        line.setBackgroundColor(0xFF2A2A2A);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        navPower = navItem(GlyphView.POWER, 0);
        navSens = navItem(GlyphView.SLIDERS, 1);
        navPowerG = (GlyphView) navPower.getChildAt(0);
        navSensG = (GlyphView) navSens.getChildAt(0);
        nav.addView(navPower, new LinearLayout.LayoutParams(0, dp(52), 1f));
        nav.addView(navSens, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(56)));
        setContentView(root);
        handleIntent(getIntent());
        show();
    }

    FrameLayout navItem(int glyph, int idx) {
        FrameLayout f = new FrameLayout(this);
        GlyphView g = new GlyphView(this, glyph, FG);
        f.addView(g, new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setOnClickListener(v -> { if (tab != idx) { tab = idx; stage = 0; show(); } });
        press(f);
        return f;
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handleIntent(i); show(); }

    void handleIntent(Intent i) {
        if (i != null && "sens".equals(i.getStringExtra("go"))) { tab = 1; stage = 0; i.removeExtra("go"); }
    }

    @Override protected void onResume() { super.onResume(); if (tab == 0 && startBtn != null) refresh(); }

    @Override public void onBackPressed() {
        if (tab == 1 && stage > 0) { stage--; show(); }
        else if (tab == 1) { tab = 0; show(); }
        else super.onBackPressed();
    }

    // ------------------------------------------------------------ navigation
    void show() {
        View page;
        if (tab == 0) page = startPage();
        else if (stage == 0) page = chooserPage();
        else if (stage == 1) page = listPage();
        else page = detailPage();
        swap(page);
        boolean power = tab == 0;
        navPower.setBackground(power ? shape(FG, 18, 0, 0) : null);
        navSens.setBackground(!power ? shape(FG, 18, 0, 0) : null);
        navPowerG.setColor(power ? BG : FG);
        navSensG.setColor(!power ? BG : FG);
        navPower.setPadding(dp(30), dp(8), dp(30), dp(8));
        navSens.setPadding(dp(30), dp(8), dp(30), dp(8));
        if (tab == 0) refresh();
    }

    void swap(View page) {
        final View old = current;
        current = page;
        page.setAlpha(0f);
        page.setTranslationY(dp(10));
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
        page.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        if (old != null) {
            old.animate().alpha(0f).setDuration(110).withEndAction(() -> content.removeView(old)).start();
        }
    }

    View banner(LinearLayout col) {
        BannerView b = new BannerView(this);
        col.addView(b, new LinearLayout.LayoutParams(-1, dp(104)));
        return b;
    }

    // ------------------------------------------------------------ start page
    View startPage() {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = vl();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        banner(col);
        TextView title = tv("Freestyle Panel", 20, FG);
        title.setPadding(0, dp(44), 0, dp(6));
        col.addView(title);
        TextView sub = tv("To access it, just click on \"Start\" and you're good to go.", 13, 0xFFCCCCCC);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(dp(16), 0, dp(16), 0);
        col.addView(sub);

        startBtn = new FrameLayout(this);
        startGlyph = new GlyphView(this, GlyphView.POWER, RED);
        startBtn.addView(startGlyph, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));
        startBtn.setOnClickListener(v -> toggleRunning());
        press(startBtn);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(116), dp(116));
        bp.topMargin = dp(52);
        bp.bottomMargin = dp(48);
        col.addView(startBtn, bp);

        // show / hide floating icon
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), 0, dp(20), 0);
        LinearLayout txt = vl();
        segTitle = tv("Show floating icon", 15, FG);
        segDesc = tv("Show icon and move the floating position freely.", 12, MUTE);
        segDesc.setPadding(0, dp(3), 0, 0);
        txt.addView(segTitle);
        txt.addView(segDesc);
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));
        segBox = new LinearLayout(this);
        segBox.setPadding(dp(3), dp(3), dp(3), dp(3));
        segBox.setBackground(shape(0, 22, FG, 2));
        seg0 = segment(GlyphView.EYE, true);
        seg1 = segment(GlyphView.EYE_OFF, false);
        g0 = (GlyphView) seg0.getChildAt(0);
        g1 = (GlyphView) seg1.getChildAt(0);
        segBox.addView(seg0, new LinearLayout.LayoutParams(dp(50), dp(34)));
        segBox.addView(seg1, new LinearLayout.LayoutParams(dp(50), dp(34)));
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(-2, -2);
        sbp.leftMargin = dp(12);
        row.addView(segBox, sbp);
        segRow = row;
        col.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // opacity
        LinearLayout op = vl();
        op.setPadding(dp(20), dp(26), dp(20), dp(20));
        op.addView(tv("Floating icon opacity", 15, FG));
        LinearLayout orow = new LinearLayout(this);
        orow.setGravity(Gravity.CENTER_VERTICAL);
        orow.setPadding(0, dp(12), 0, 0);
        FrameLayout box = new FrameLayout(this);
        box.setBackground(shape(FG, 8, 0, 0));
        box.addView(new GlyphView(this, GlyphView.PIP, BG), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        orow.addView(box, new LinearLayout.LayoutParams(dp(32), dp(32)));
        opBar = new SeekBar(this);
        opBar.setMax(90);
        opBar.setProgress(Math.max(10, sp.getInt("opacity", 100)) - 10);
        opBar.setProgressTintList(ColorStateList.valueOf(FG));
        opBar.setThumbTintList(ColorStateList.valueOf(FG));
        opBar.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF4A4A4A));
        opVal = tv(sp.getInt("opacity", 100) + "%", 13, FG);
        opVal.setGravity(Gravity.END);
        opBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                int v = p + 10;
                opVal.setText(v + "%");
                if (user) sp.edit().putInt("opacity", v).apply();
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        LinearLayout.LayoutParams bar = new LinearLayout.LayoutParams(0, -2, 1f);
        bar.leftMargin = dp(8);
        orow.addView(opBar, bar);
        orow.addView(opVal, new LinearLayout.LayoutParams(dp(52), -2));
        op.addView(orow);
        opRow = op;
        col.addView(op, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(col);
        return sv;
    }

    FrameLayout segment(int glyph, boolean eyeOn) {
        FrameLayout f = new FrameLayout(this);
        f.addView(new GlyphView(this, glyph, FG), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        f.setOnClickListener(v -> {
            if (!FloatingService.running) { toast("Press Start first"); return; }
            sp.edit().putBoolean("iconShow", eyeOn).apply();
            refresh();
        });
        return f;
    }

    void refresh() {
        if (startBtn == null) return;
        boolean on = FloatingService.running;
        boolean showIcon = sp.getBoolean("iconShow", true);
        startBtn.setBackground(shape(0, 30, on ? GREEN : RED, 2));
        startGlyph.setColor(on ? GREEN : 0xFF7A7A7A);
        segTitle.setText(showIcon ? "Show floating icon" : "Hide floating icon");
        segDesc.setText(showIcon ? "Show icon and move the floating position freely." : "Hide the icon and lock the floating position.");
        int sel = on ? FG : 0xFF555555;
        seg0.setBackground(showIcon ? shape(sel, 17, 0, 0) : null);
        seg1.setBackground(!showIcon ? shape(sel, 17, 0, 0) : null);
        g0.setColor(showIcon ? BG : FG);
        g1.setColor(!showIcon ? BG : FG);
        segRow.setAlpha(on ? 1f : .45f);
        opRow.setAlpha(on ? 1f : .45f);
        opBar.setEnabled(on);
    }

    void toggleRunning() {
        if (FloatingService.running) {
            stopService(new Intent(this, FloatingService.class));
            FloatingService.running = false;
            refresh();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\", then press Start again.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        try {
            startForegroundService(new Intent(this, FloatingService.class));
            FloatingService.running = true;
        } catch (Throwable t) {
            toast("Couldn't start the panel");
        }
        refresh();
    }

    // ------------------------------------------------------------ sensitivity pages
    View chooserPage() {
        LinearLayout col = vl();
        banner(col);
        LinearLayout mid = vl();
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        mid.setPadding(dp(28), 0, dp(28), dp(40));
        mid.addView(new GlyphView(this, GlyphView.SLIDERS, FG), new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = tv("Choose the maximum sensitivity for freestyle.", 15, FG);
        t.setLetterSpacing(0.08f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(16), 0, dp(22));
        mid.addView(t);
        mid.addView(pillButton("FREESTYLE SENSITIVITY 100X", 100));
        mid.addView(pillButton("FREESTYLE SENSITIVITY 200X", 200));
        col.addView(mid, new LinearLayout.LayoutParams(-1, 0, 1f));
        ((LinearLayout.LayoutParams) mid.getLayoutParams()).gravity = Gravity.CENTER;
        mid.setGravity(Gravity.CENTER);
        return col;
    }

    View pillButton(String label, int m) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(FG, 30, 0, 0));
        TextView t = tv(label, 11.5f, BG);
        t.setLetterSpacing(0.12f);
        b.addView(t);
        TextView a = tv("  →", 15, BG);
        a.setTypeface(null, Typeface.BOLD);
        b.addView(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> { mode = m; stage = 1; show(); });
        press(b);
        return b;
    }

    View listPage() {
        LinearLayout col = vl();
        banner(col);
        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER_VERTICAL);
        chips.setPadding(dp(8), dp(10), dp(8), dp(10));
        final ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        final LinearLayout cards = vl();
        cards.setPadding(dp(14), dp(4), dp(14), dp(16));
        sv.addView(cards);
        final TextView[] chipViews = new TextView[4];
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView c = tv(TABS[i], 14, FG);
            c.setGravity(Gravity.CENTER);
            chips.addView(c, new LinearLayout.LayoutParams(0, dp(40), 1f));
            chipViews[i] = c;
            c.setOnClickListener(v -> {
                dpiTab = idx;
                paintChips(chipViews);
                fillCards(cards);
                sv.scrollTo(0, 0);
            });
            press(c);
        }
        paintChips(chipViews);
        fillCards(cards);
        col.addView(chips, new LinearLayout.LayoutParams(-1, -2));
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    void paintChips(TextView[] cs) {
        for (int i = 0; i < cs.length; i++) {
            boolean sel = i == dpiTab;
            cs[i].setBackground(sel ? shape(FG, 20, 0, 0) : null);
            cs[i].setTextColor(sel ? BG : FG);
        }
    }

    void fillCards(LinearLayout cards) {
        cards.removeAllViews();
        for (int s = 0; s < DATA[dpiTab].length; s++) cards.addView(card(s));
        cards.setAlpha(0f);
        cards.animate().alpha(1f).setDuration(180).start();
    }

    View card(final int set) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(shape(0, 20, FG, 1));
        LinearLayout rows = vl();
        rows.setPadding(dp(14), dp(12), dp(14), dp(16));
        int[] v = DATA[dpiTab][set];
        for (int i = 0; i < 5; i++) {
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setAlpha(FADE[i]);
            FrameLayout ib = new FrameLayout(this);
            ib.setBackground(shape(FG, 5, 0, 0));
            ib.addView(new GlyphView(this, ICONS[i], BG), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
            r.addView(ib, new LinearLayout.LayoutParams(dp(20), dp(20)));
            TextView l = tv(LABELS[i] + ":", 12.5f, FG);
            l.setPadding(dp(8), 0, 0, 0);
            r.addView(l, new LinearLayout.LayoutParams(dp(84), -2));
            r.addView(new BarView(this, v[i]), new LinearLayout.LayoutParams(0, dp(16), 1f));
            TextView val = tv(String.valueOf(v[i]), 12.5f, FG);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(dp(34), -2));
            rows.addView(r, new LinearLayout.LayoutParams(-1, dp(32)));
        }
        f.addView(rows, new FrameLayout.LayoutParams(-1, -2));
        TextView tag = tv("Sensitivity " + (set + 1), 13, BG);
        tag.setPadding(dp(16), dp(9), dp(16), dp(9));
        float r = dp(20);
        GradientDrawable tb = new GradientDrawable();
        tb.setColor(FG);
        tb.setCornerRadii(new float[]{r, r, 0, 0, r, r, 0, 0});
        tag.setBackground(tb);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        f.addView(tag, tp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        lp.bottomMargin = dp(6);
        f.setLayoutParams(lp);
        f.setOnClickListener(v2 -> { detailSet = set; stage = 2; show(); });
        press(f);
        return f;
    }

    View detailPage() {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = vl();
        col.setPadding(dp(18), dp(20), dp(18), dp(24));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout back = new FrameLayout(this);
        back.setBackground(shape(FG, 10, 0, 0));
        back.addView(new GlyphView(this, GlyphView.SLIDERS, BG), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        back.setOnClickListener(v -> { stage = 1; show(); });
        press(back);
        head.addView(back, new LinearLayout.LayoutParams(dp(40), dp(40)));
        View sp1 = new View(this);
        head.addView(sp1, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView pill = tv(TABS[dpiTab], 13, BG);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(18), dp(8), dp(18), dp(8));
        pill.setBackground(shape(FG, 20, 0, 0));
        head.addView(pill);
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = tv("Sensitivity " + (detailSet + 1) + "  ·  " + mode + "X", 13, MUTE);
        sub.setPadding(0, dp(22), 0, dp(8));
        col.addView(sub);
        int[] v = DATA[dpiTab][detailSet];
        for (int i = 0; i < 5; i++) {
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(new GlyphView(this, ICONS[i], FG), new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView l = tv(LABELS[i], 14, FG);
            l.setPadding(dp(10), 0, 0, 0);
            r.addView(l, new LinearLayout.LayoutParams(dp(92), -2));
            r.addView(new BarView(this, v[i]), new LinearLayout.LayoutParams(0, dp(20), 1f));
            TextView val = tv(String.valueOf(v[i]), 13, FG);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(dp(34), -2));
            col.addView(r, new LinearLayout.LayoutParams(-1, dp(40)));
        }
        LinearLayout fire = new LinearLayout(this);
        fire.setGravity(Gravity.CENTER_VERTICAL);
        fire.addView(new GlyphView(this, GlyphView.FIRE, FG), new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView fl = tv("Fire button", 14, FG);
        fl.setPadding(dp(10), 0, 0, 0);
        fire.addView(fl, new LinearLayout.LayoutParams(0, -2, 1f));
        fire.addView(tv(String.valueOf(41 + detailSet * 2 - dpiTab), 13, 0xFFBBBBBB));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(40));
        fp.topMargin = dp(26);
        col.addView(fire, fp);

        TextView cp = tv("Cursor/Pointer Speed", 14, FG);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, dp(34), 0, dp(6));
        col.addView(cp);
        SeekBar speed = new SeekBar(this);
        speed.setMax(100);
        speed.setProgress(sp.getInt("pointer", 100));
        speed.setProgressTintList(ColorStateList.valueOf(FG));
        speed.setThumbTintList(ColorStateList.valueOf(FG));
        speed.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF4A4A4A));
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) sp.edit().putInt("pointer", p).apply(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        col.addView(speed, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout lab = new LinearLayout(this);
        String[] ls = {"Minimum", "Average", "Maximum"};
        for (int i = 0; i < 3; i++) {
            TextView t = tv(ls[i], 13, FG);
            t.setGravity(i == 0 ? Gravity.START : i == 2 ? Gravity.END : Gravity.CENTER);
            lab.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        col.addView(lab);
        sv.addView(col);
        return sv;
    }
}
