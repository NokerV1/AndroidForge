package com.example.neonrobloxbooster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(20, 24, 32)
    private val neon = Color.rgb(91, 255, 190)
    private val muted = Color.rgb(164, 174, 188)
    private lateinit var refreshValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(1), stroke)
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
    }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(if (primary) Color.rgb(7, 19, 14) else Color.WHITE)
            background = rounded(if (primary) neon else Color.rgb(37, 44, 55), 14)
            minHeight = dp(48)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { action() }
        }
    }

    private fun card(title: String, description: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 18, Color.rgb(40, 51, 61))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(text(title, 17f, Color.WHITE, true))
            val desc = text(description, 13f, muted)
            desc.setPadding(dp(2), dp(6), dp(2), dp(10))
            addView(desc)
        }
    }

    private fun addCard(parent: LinearLayout, child: View) {
        parent.addView(child, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("NEON / BOOSTER", 12f, neon, true))
        val title = text("Roblox Booster", 29f, Color.WHITE, true)
        title.setPadding(0, dp(5), 0, dp(2))
        root.addView(title)
        root.addView(text("A clean toolkit for your Android gaming setup.", 14f, muted))
        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, dp(18)))

        val hero = card("READY WHEN YOU ARE", "Launch Roblox and check useful device performance details. This app does not modify Roblox files or promise extra FPS.")
        hero.addView(button("▶   Launch Roblox", true) { launchRoblox() })
        addCard(root, hero)

        val fpsCard = card("FPS / DISPLAY INFO", "Android apps generally cannot read Roblox's live in-game FPS unless Roblox exposes it.")
        refreshValue = text("Checking display refresh rate…", 16f, neon, true)
        fpsCard.addView(refreshValue)
        fpsCard.addView(text("Refresh rate is your display's Hz, not Roblox FPS.", 12f, muted))
        addCard(root, fpsCard)
        updateRefreshRate()

        val performance = card("SAFE PERFORMANCE TOOLS", "These buttons open Android settings so you can make changes yourself.")
        performance.addView(button("Open display settings") {
            openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS), "Display settings unavailable")
        })
        performance.addView(button("Open app / battery settings") {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            openSettings(intent, "App settings unavailable")
        }.apply { setMarginsCompat(top = 8) })
        performance.addView(button("Open battery saver settings") {
            openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), "Battery settings unavailable")
        }.apply { setMarginsCompat(top = 8) })
        addCard(root, performance)

        val tips = card("QUICK TIPS", "• Turn on your phone's built-in game mode, if available.\n• Use a stable Wi-Fi connection.\n• Close apps you are actively using only when needed.\n• Lower Roblox in-game graphics if performance is poor.\n• Let the phone cool down if it becomes hot.")
        addCard(root, tips)

        val footer = text("No root • No file patching • No guaranteed FPS gains", 11f, muted)
        footer.gravity = Gravity.CENTER
        footer.setPadding(0, dp(4), 0, dp(8))
        root.addView(footer)
    }

    private fun View.setMarginsCompat(top: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(top)
        layoutParams = lp
    }

    private fun updateRefreshRate() {
        val rate = if (android.os.Build.VERSION.SDK_INT >= 30) {
            display?.refreshRate
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate
        }
        refreshValue.text = if (rate != null && rate > 0f) {
            "Display: ${rate.roundToInt()} Hz"
        } else {
            "Display refresh rate unavailable"
        }
    }

    private fun launchRoblox() {
        val launch = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else {
            Toast.makeText(this, "Roblox isn't installed. Install it from Google Play first.", Toast.LENGTH_LONG).show()
            openSettings(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.roblox.client")), "Could not open Play Store")
        }
    }

    private fun openSettings(intent: Intent, error: String) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::refreshValue.isInitialized) updateRefreshRate()
    }
}
