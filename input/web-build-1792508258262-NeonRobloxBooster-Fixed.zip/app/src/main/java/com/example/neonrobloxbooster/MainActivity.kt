package com.example.neonrobloxbooster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(20, 24, 32)
    private val neon = Color.rgb(91, 255, 190)
    private val muted = Color.rgb(164, 174, 188)
    private lateinit var refreshValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun shape(color: Int, radius: Int = 18, stroke: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun makeButton(caption: String, primary: Boolean = false, action: () -> Unit) =
        Button(this).apply {
            text = caption
            textSize = 14f
            isAllCaps = false
            setTextColor(if (primary) Color.rgb(7, 19, 14) else Color.WHITE)
            background = shape(if (primary) neon else Color.rgb(37, 44, 55), 14)
            setOnClickListener { action() }
        }

    private fun makeCard(title: String, desc: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(panel, 18, Color.rgb(40, 51, 61))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(label(title, 17f, Color.WHITE, true))
            addView(label(desc, 13f, muted).apply { setPadding(0, dp(6), 0, dp(10)) })
        }

    private fun addCard(root: LinearLayout, view: View) {
        root.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(label("NEON / BOOSTER", 12f, neon, true))
        root.addView(label("Roblox Booster", 29f, Color.WHITE, true).apply {
            setPadding(0, dp(5), 0, dp(2))
        })
        root.addView(label("A clean toolkit for your Android gaming setup.", 14f, muted))
        addCard(root, makeCard("READY WHEN YOU ARE",
            "Launch Roblox and check device display details. This app does not modify Roblox files or promise extra FPS.").apply {
            addView(makeButton("▶   Launch Roblox", true) { launchRoblox() })
        })
        addCard(root, makeCard("FPS / DISPLAY INFO",
            "Android apps generally cannot read Roblox's live in-game FPS unless Roblox exposes it.").apply {
            refreshValue = label("Checking display refresh rate…", 16f, neon, true)
            addView(refreshValue)
            addView(label("Refresh rate is your display's Hz, not Roblox FPS.", 12f, muted))
        })
        updateRefreshRate()
        addCard(root, makeCard("SAFE PERFORMANCE TOOLS",
            "These buttons open Android settings so you can make changes yourself.").apply {
            addView(makeButton("Open display settings") {
                openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            })
            addView(makeButton("Open app / battery settings") {
                openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                })
            })
            addView(makeButton("Open battery saver settings") {
                openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            })
        })
        addCard(root, makeCard("QUICK TIPS",
            "• Turn on your phone's built-in game mode, if available.\n• Use stable Wi-Fi.\n• Lower Roblox in-game graphics if performance is poor.\n• Let the phone cool down if it becomes hot."))
        root.addView(label("No root • No file patching • No guaranteed FPS gains", 11f, muted).apply {
            gravity = android.view.Gravity.CENTER
        })
    }

    private fun updateRefreshRate() {
        val rate = if (android.os.Build.VERSION.SDK_INT >= 30) display?.refreshRate
        else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate
        }
        refreshValue.text = if (rate != null && rate > 0f) "Display: ${rate.roundToInt()} Hz"
        else "Display refresh rate unavailable"
    }

    private fun launchRoblox() {
        val launch = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (launch != null) startActivity(launch)
        else {
            Toast.makeText(this, "Install Roblox from Google Play first.", Toast.LENGTH_LONG).show()
            openSettings(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=com.roblox.client")))
        }
    }

    private fun openSettings(intent: Intent) {
        try { startActivity(intent) }
        catch (_: Exception) {
            Toast.makeText(this, "That setting isn't available on this device.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::refreshValue.isInitialized) updateRefreshRate()
    }
}
