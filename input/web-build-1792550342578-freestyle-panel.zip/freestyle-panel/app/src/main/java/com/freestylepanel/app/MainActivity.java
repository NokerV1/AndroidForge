package com.freestylepanel.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final int BG = 0xFF000000, FG = 0xFFFFFFFF, MUTE = 0xFF8E8E8E, GREEN = 0xFF1DD18B, RED = 0xFFE53935;

    SharedPreferences sp;
    FrameLayout content;
    View current;
    FrameLayout navPower, navSens;
    GlyphView navPowerG, navSensG;
    int tab = 0;
    SensitivityPanel panel;

    // start-page widgets
    FrameLayout startBtn, seg0, seg1;
    GlyphView startGlyph, g0, g1;
    TextView segTitle, segDesc, opVal;
    LinearLayout segBox;
    SeekBar opBar;
    View segRow, opRow;

    // ------------------------------------------------------------ helpers
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable shape(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    LinearLayout vl() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new OvershootInterpolator(2.5f)).start();
            return false;
        });
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------ lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("fp", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        LinearLayout root = vl();
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        View line = new View(this);
        line.setBackgroundColor(0xFF2A2A2A);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        navPower = navItem(GlyphView.POWER, 0);
        navSens = navItem(GlyphView.SLIDERS, 1);
        navPowerG = (GlyphView) navPower.getChildAt(0);
        navSensG = (GlyphView) navSens.getChildAt(0);
        nav.addView(navPower, new LinearLayout.LayoutParams(0, dp(52), 1f));
        nav.addView(navSens, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(56)));
        setContentView(root);
        handleIntent(getIntent());
        show();
    }

    FrameLayout navItem(int glyph, int idx) {
        FrameLayout f = new FrameLayout(this);
        GlyphView g = new GlyphView(this, glyph, FG);
        f.addView(g, new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setOnClickListener(v -> { if (tab != idx) { tab = idx; show(); } });
        press(f);
        return f;
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handleIntent(i); show(); }

    void handleIntent(Intent i) {
        if (i != null && "sens".equals(i.getStringExtra("go"))) { tab = 1; i.removeExtra("go"); }
    }

    @Override protected void onResume() { super.onResume(); if (tab == 0 && startBtn != null) refresh(); }

    @Override public void onBackPressed() {
        if (tab == 1) {
            if (panel == null || !panel.back()) { tab = 0; show(); }
        } else super.onBackPressed();
    }

    // ------------------------------------------------------------ navigation
    void show() {
        View page;
        page = tab == 0 ? startPage() : panelPage();
        swap(page);
        boolean power = tab == 0;
        navPower.setBackground(power ? shape(FG, 18, 0, 0) : null);
        navSens.setBackground(!power ? shape(FG, 18, 0, 0) : null);
        navPowerG.setColor(power ? BG : FG);
        navSensG.setColor(!power ? BG : FG);
        navPower.setPadding(dp(30), dp(8), dp(30), dp(8));
        navSens.setPadding(dp(30), dp(8), dp(30), dp(8));
        if (tab == 0) refresh();
    }

    void swap(View page) {
        final View old = current;
        current = page;
        page.setAlpha(0f);
        page.setTranslationY(dp(10));
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
        page.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        if (old != null) {
            old.animate().alpha(0f).setDuration(110).withEndAction(() -> content.removeView(old)).start();
        }
    }

    View banner(LinearLayout col) {
        BannerView b = new BannerView(this);
        col.addView(b, new LinearLayout.LayoutParams(-1, dp(104)));
        return b;
    }

    // ------------------------------------------------------------ start page
    View startPage() {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = vl();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        banner(col);
        TextView title = tv("Freestyle Panel", 20, FG);
        title.setPadding(0, dp(44), 0, dp(6));
        col.addView(title);
        TextView sub = tv("To access it, just click on \"Start\" and you're good to go.", 13, 0xFFCCCCCC);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(dp(16), 0, dp(16), 0);
        col.addView(sub);

        startBtn = new FrameLayout(this);
        startGlyph = new GlyphView(this, GlyphView.POWER, RED);
        startBtn.addView(startGlyph, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));
        startBtn.setOnClickListener(v -> toggleRunning());
        press(startBtn);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(116), dp(116));
        bp.topMargin = dp(52);
        bp.bottomMargin = dp(48);
        col.addView(startBtn, bp);

        // show / hide floating icon
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20), 0, dp(20), 0);
        LinearLayout txt = vl();
        segTitle = tv("Show floating icon", 15, FG);
        segDesc = tv("Show icon and move the floating position freely.", 12, MUTE);
        segDesc.setPadding(0, dp(3), 0, 0);
        txt.addView(segTitle);
        txt.addView(segDesc);
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));
        segBox = new LinearLayout(this);
        segBox.setPadding(dp(3), dp(3), dp(3), dp(3));
        segBox.setBackground(shape(0, 22, FG, 2));
        seg0 = segment(GlyphView.EYE, true);
        seg1 = segment(GlyphView.EYE_OFF, false);
        g0 = (GlyphView) seg0.getChildAt(0);
        g1 = (GlyphView) seg1.getChildAt(0);
        segBox.addView(seg0, new LinearLayout.LayoutParams(dp(50), dp(34)));
        segBox.addView(seg1, new LinearLayout.LayoutParams(dp(50), dp(34)));
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(-2, -2);
        sbp.leftMargin = dp(12);
        row.addView(segBox, sbp);
        segRow = row;
        col.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // opacity
        LinearLayout op = vl();
        op.setPadding(dp(20), dp(26), dp(20), dp(20));
        op.addView(tv("Floating icon opacity", 15, FG));
        LinearLayout orow = new LinearLayout(this);
        orow.setGravity(Gravity.CENTER_VERTICAL);
        orow.setPadding(0, dp(12), 0, 0);
        FrameLayout box = new FrameLayout(this);
        box.setBackground(shape(FG, 8, 0, 0));
        box.addView(new GlyphView(this, GlyphView.PIP, BG), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        orow.addView(box, new LinearLayout.LayoutParams(dp(32), dp(32)));
        opBar = new SeekBar(this);
        opBar.setMax(90);
        opBar.setProgress(Math.max(10, sp.getInt("opacity", 100)) - 10);
        opBar.setProgressTintList(ColorStateList.valueOf(FG));
        opBar.setThumbTintList(ColorStateList.valueOf(FG));
        opBar.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF4A4A4A));
        opVal = tv(sp.getInt("opacity", 100) + "%", 13, FG);
        opVal.setGravity(Gravity.END);
        opBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                int v = p + 10;
                opVal.setText(v + "%");
                if (user) sp.edit().putInt("opacity", v).apply();
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        LinearLayout.LayoutParams bar = new LinearLayout.LayoutParams(0, -2, 1f);
        bar.leftMargin = dp(8);
        orow.addView(opBar, bar);
        orow.addView(opVal, new LinearLayout.LayoutParams(dp(52), -2));
        op.addView(orow);
        opRow = op;
        col.addView(op, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(col);
        return sv;
    }

    FrameLayout segment(int glyph, boolean eyeOn) {
        FrameLayout f = new FrameLayout(this);
        f.addView(new GlyphView(this, glyph, FG), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        f.setOnClickListener(v -> {
            if (!FloatingService.running) { toast("Press Start first"); return; }
            sp.edit().putBoolean("iconShow", eyeOn).apply();
            refresh();
        });
        return f;
    }

    void refresh() {
        if (startBtn == null) return;
        boolean on = FloatingService.running;
        boolean showIcon = sp.getBoolean("iconShow", true);
        startBtn.setBackground(shape(0, 30, on ? GREEN : RED, 2));
        startGlyph.setColor(on ? GREEN : 0xFF7A7A7A);
        segTitle.setText(showIcon ? "Show floating icon" : "Hide floating icon");
        segDesc.setText(showIcon ? "Show icon and move the floating position freely." : "Hide the icon and lock the floating position.");
        int sel = on ? FG : 0xFF555555;
        seg0.setBackground(showIcon ? shape(sel, 17, 0, 0) : null);
        seg1.setBackground(!showIcon ? shape(sel, 17, 0, 0) : null);
        g0.setColor(showIcon ? BG : FG);
        g1.setColor(!showIcon ? BG : FG);
        segRow.setAlpha(on ? 1f : .45f);
        opRow.setAlpha(on ? 1f : .45f);
        opBar.setEnabled(on);
    }

    void toggleRunning() {
        if (FloatingService.running) {
            stopService(new Intent(this, FloatingService.class));
            FloatingService.running = false;
            refresh();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\", then press Start again.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        try {
            startForegroundService(new Intent(this, FloatingService.class));
            FloatingService.running = true;
        } catch (Throwable t) {
            toast("Couldn't start the panel");
        }
        refresh();
    }

    View panelPage() {
        panel = new SensitivityPanel(this, true);
        return panel;
    }
}
