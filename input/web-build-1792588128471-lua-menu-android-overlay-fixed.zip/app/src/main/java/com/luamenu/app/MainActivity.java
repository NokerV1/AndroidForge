package com.luamenu.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_REQUEST = 1;
    private WebView web;
    private WebView floatingWeb;
    private WindowManager windowManager;
    private WindowManager.LayoutParams floatingParams;
    private ValueCallback<Uri[]> pending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        web = new WebView(this);
        configureWebView(web);
        setContentView(web);
        web.addJavascriptInterface(new OverlayBridge(false), "AndroidOverlay");
        web.setWebChromeClient(makeChromeClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        view.setBackgroundColor(Color.TRANSPARENT);
        view.setWebViewClient(new WebViewClient());
    }

    private WebChromeClient makeChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pending != null) pending.onReceiveValue(null);
                pending = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Select Lua text file"), PICK_REQUEST);
                } catch (Exception e) {
                    pending = null;
                    return false;
                }
                return true;
            }
        };
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showFloatingMenu() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Appear on top first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (floatingWeb != null) {
            floatingWeb.setVisibility(View.VISIBLE);
            return;
        }

        floatingWeb = new WebView(this);
        configureWebView(floatingWeb);
        floatingWeb.addJavascriptInterface(new OverlayBridge(true), "AndroidOverlay");
        floatingWeb.setWebChromeClient(makeChromeClient());

        int width = Math.min(dp(360), getResources().getDisplayMetrics().widthPixels - dp(20));
        int height = Math.min(dp(560), getResources().getDisplayMetrics().heightPixels - dp(80));
        floatingParams = new WindowManager.LayoutParams(
                Math.max(dp(280), width), Math.max(dp(300), height),
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        floatingParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        floatingParams.y = dp(36);
        try {
            windowManager.addView(floatingWeb, floatingParams);
            floatingWeb.loadUrl("file:///android_asset/index.html");
        } catch (Exception e) {
            floatingWeb = null;
            Toast.makeText(this, "Could not open floating menu: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void closeFloatingMenu() {
        if (floatingWeb != null) {
            try { windowManager.removeView(floatingWeb); } catch (Exception ignored) {}
            floatingWeb.destroy();
            floatingWeb = null;
            floatingParams = null;
        }
    }

    private class OverlayBridge {
        private final boolean isFloating;
        OverlayBridge(boolean floating) { isFloating = floating; }

        @JavascriptInterface
        public boolean hasPermission() {
            return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(MainActivity.this);
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Appear on top permission is already enabled", Toast.LENGTH_SHORT).show();
                    showFloatingMenu();
                }
            });
        }

        @JavascriptInterface
        public boolean isFloating() {
            return floatingWeb != null;
        }

        @JavascriptInterface
        public void openOverlay() {
            runOnUiThread(() -> showFloatingMenu());
        }

        @JavascriptInterface
        public void closeOverlay() {
            runOnUiThread(() -> closeFloatingMenu());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.post(() -> web.evaluateJavascript(
                "if(window.updateOverlayStatus) updateOverlayStatus();", null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_REQUEST && pending != null) {
            pending.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pending = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onDestroy() {
        closeFloatingMenu();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
