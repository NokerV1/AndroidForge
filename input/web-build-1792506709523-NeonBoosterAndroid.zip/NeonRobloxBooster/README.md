# Neon Roblox Booster (Android)

A small native Android app with a black/neon interface, Roblox launch button, display refresh-rate information, and shortcuts to Android's own settings.

## Important limits
- The displayed Hz value is the screen refresh rate, **not** live Roblox FPS.
- Android does not generally let a normal third-party app read Roblox's live FPS or safely force Roblox to render faster.
- This app does not kill other apps, change Roblox files, require root, or claim guaranteed performance gains.
- Settings availability varies by Android version and device manufacturer.

## Build an APK with Android Studio
1. Install Android Studio and a compatible Android SDK (API 35).
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the `NeonRobloxBooster` folder.
4. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks you to select a Gradle JDK.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
8. To install on your phone, copy the APK to the device and open it. Android may ask you to allow installs from that file manager. Only install APKs you built or otherwise trust.

## Project details
- Kotlin, native Android Views
- Min SDK 23
- Target SDK 35
- No third-party libraries and no special permissions
- Application ID: `com.example.neonrobloxbooster`

## Troubleshooting
- If Gradle sync fails, check your internet connection and that Android Studio has downloaded Android Gradle Plugin 8.7.3, Kotlin plugin 2.0.21, and SDK Platform 35.
- If Roblox does not launch, install/update the official Roblox app first.
