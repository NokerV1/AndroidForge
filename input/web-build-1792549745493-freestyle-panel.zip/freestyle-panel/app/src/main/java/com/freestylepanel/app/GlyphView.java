package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Small line icons drawn in code (power, sliders, eye, aim reticles...). */
class GlyphView extends View {
    static final int POWER = 0, SLIDERS = 1, EYE = 2, EYE_OFF = 3, PIP = 4,
            AIM = 5, AIM_RED = 6, AIM_2X = 7, AIM_4X = 8, AIM_AWM = 9, FIRE = 10;
    private final int type;
    private int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    GlyphView(Context c, int type, int color) {
        super(c);
        this.type = type;
        this.color = color;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    void setColor(int c) { color = c; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f, s * 0.085f));
        switch (type) {
            case POWER: {
                RectF r = new RectF(cx - .34f * s, cy - .30f * s, cx + .34f * s, cy + .38f * s);
                c.drawArc(r, -55, 290, false, p);
                c.drawLine(cx, cy - .42f * s, cx, cy - .06f * s, p);
                break;
            }
            case SLIDERS: {
                float[] ys = {-.26f, 0f, .26f};
                float[] ks = {-.12f, .16f, -.02f};
                for (int i = 0; i < 3; i++) {
                    c.drawLine(cx - .38f * s, cy + ys[i] * s, cx + .38f * s, cy + ys[i] * s, p);
                    c.drawLine(cx + ks[i] * s, cy + ys[i] * s - .1f * s, cx + ks[i] * s, cy + ys[i] * s + .1f * s, p);
                }
                break;
            }
            case EYE:
            case EYE_OFF: {
                Path e = new Path();
                e.moveTo(cx - .4f * s, cy);
                e.quadTo(cx, cy - .42f * s, cx + .4f * s, cy);
                e.quadTo(cx, cy + .42f * s, cx - .4f * s, cy);
                c.drawPath(e, p);
                c.drawCircle(cx, cy, .11f * s, p);
                if (type == EYE_OFF) c.drawLine(cx - .34f * s, cy + .34f * s, cx + .34f * s, cy - .34f * s, p);
                break;
            }
            case PIP: {
                c.drawRoundRect(new RectF(cx - .36f * s, cy - .3f * s, cx + .36f * s, cy + .3f * s), .08f * s, .08f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawRect(cx + .02f * s, cy - .2f * s, cx + .26f * s, cy - .02f * s, p);
                break;
            }
            case FIRE: {
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, .4f * s, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFF000000);
                p.setStrokeWidth(Math.max(2f, s * 0.07f));
                c.drawCircle(cx, cy, .2f * s, p);
                break;
            }
            default: {
                p.setStrokeWidth(Math.max(1.5f, s * 0.07f));
                float r = .34f * s;
                c.drawCircle(cx, cy, r, p);
                if (type == AIM) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy, .08f * s, p);
                } else if (type == AIM_RED) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy, .06f * s, p);
                    p.setStyle(Paint.Style.STROKE);
                    c.drawLine(cx, cy - r, cx, cy - r + .1f * s, p);
                    c.drawLine(cx, cy + r, cx, cy + r - .1f * s, p);
                } else if (type == AIM_2X) {
                    c.drawCircle(cx, cy, .14f * s, p);
                } else if (type == AIM_4X) {
                    c.drawLine(cx - r, cy, cx - .1f * s, cy, p);
                    c.drawLine(cx + r, cy, cx + .1f * s, cy, p);
                    c.drawLine(cx, cy - r, cx, cy - .1f * s, p);
                    c.drawLine(cx, cy + r, cx, cy + .1f * s, p);
                } else {
                    c.drawLine(cx - r - .08f * s, cy, cx + r + .08f * s, cy, p);
                    c.drawLine(cx, cy - r - .08f * s, cx, cy + r + .08f * s, p);
                }
            }
        }
    }
}
