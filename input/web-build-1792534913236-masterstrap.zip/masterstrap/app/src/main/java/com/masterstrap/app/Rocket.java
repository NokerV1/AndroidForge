package com.masterstrap.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

final class Rocket {
    private Rocket() {}

    /** Draws the rocket centred on (cx, cy); s is half the rocket height. */
    static void draw(Canvas c, float cx, float cy, float s, boolean flame) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (flame) {
            p.setColor(0xFFFFB020);
            Path f = new Path();
            f.moveTo(cx - 0.22f * s, cy + 0.55f * s);
            f.lineTo(cx, cy + 1.25f * s);
            f.lineTo(cx + 0.22f * s, cy + 0.55f * s);
            f.close();
            c.drawPath(f, p);
        }
        p.setColor(0xFF1E9BF0);
        Path fins = new Path();
        fins.moveTo(cx - 0.32f * s, cy + 0.1f * s);
        fins.lineTo(cx - 0.75f * s, cy + 0.7f * s);
        fins.lineTo(cx - 0.3f * s, cy + 0.5f * s);
        fins.close();
        fins.moveTo(cx + 0.32f * s, cy + 0.1f * s);
        fins.lineTo(cx + 0.75f * s, cy + 0.7f * s);
        fins.lineTo(cx + 0.3f * s, cy + 0.5f * s);
        fins.close();
        c.drawPath(fins, p);
        p.setColor(0xFFE8F1FF);
        Path b = new Path();
        b.moveTo(cx, cy - s);
        b.cubicTo(cx + 0.55f * s, cy - 0.5f * s, cx + 0.5f * s, cy + 0.2f * s, cx + 0.3f * s, cy + 0.6f * s);
        b.lineTo(cx - 0.3f * s, cy + 0.6f * s);
        b.cubicTo(cx - 0.5f * s, cy + 0.2f * s, cx - 0.55f * s, cy - 0.5f * s, cx, cy - s);
        b.close();
        c.drawPath(b, p);
        p.setColor(0xFF1E9BF0);
        c.drawCircle(cx, cy - 0.2f * s, 0.16f * s, p);
    }
}
