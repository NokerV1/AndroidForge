package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Original decorative art: a landscape phone held in two hands (drawn in code). */
class GripView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int hz;          // shown label (0 = none)
    private int oldHz;       // previous label, fading out
    private float t = 1f;    // 0..1 transition progress
    private ValueAnimator anim;

    GripView(Context c) { super(c); }

    void setHz(int value) { setHz(value, true); }

    /** Changes the number on the phone screen with a smooth slide/fade (and a short "refresh" pulse). */
    void setHz(int value, boolean animate) {
        if (value == hz && t >= 1f) return;
        oldHz = hz;
        hz = value;
        if (anim != null) anim.cancel();
        if (!animate) { t = 1f; invalidate(); return; }
        t = 0f;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(380);
        anim.setInterpolator(new DecelerateInterpolator(2f));
        anim.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
        anim.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
        float cx = w / 2f, cy = h * 0.42f;
        c.save();
        c.rotate(-5, cx, cy);
        RectF phone = new RectF(cx - w * 0.36f, cy - h * 0.26f, cx + w * 0.36f, cy + h * 0.26f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFEDEDED);
        c.drawRoundRect(phone, 10 * d, 10 * d, p);
        p.setColor(0xFF000000);
        c.drawRoundRect(new RectF(phone.left + 5 * d, phone.top + 5 * d, phone.right - 5 * d, phone.bottom - 5 * d), 7 * d, 7 * d, p);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(11 * d);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(15 * d);
        p.setFakeBoldText(true);
        float base = cy + 5 * d, slide = 14 * d;
        if (t < 1f && oldHz > 0) {           // old value slides up and fades out
            p.setAlpha((int) (255 * (1f - t)));
            c.drawText(oldHz + " FPS", cx, base - slide * t, p);
        }
        if (hz > 0) {                        // new value slides in from below and fades in
            p.setAlpha((int) (255 * t));
            c.drawText(hz + " FPS", cx, base + slide * (1f - t), p);
        }
        p.setAlpha(255);
        p.setFakeBoldText(false);
        c.restore();
        // hands: simple outlined curves
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFFFFFFFF);
        Path l = new Path();
        l.moveTo(w * 0.04f, h * 0.98f);
        l.cubicTo(w * 0.04f, h * 0.7f, w * 0.12f, h * 0.55f, w * 0.3f, h * 0.62f);
        l.quadTo(w * 0.4f, h * 0.7f, w * 0.3f, h * 0.78f);
        c.drawPath(l, p);
        Path r = new Path();
        r.moveTo(w * 0.96f, h * 0.98f);
        r.cubicTo(w * 0.98f, h * 0.7f, w * 0.88f, h * 0.55f, w * 0.7f, h * 0.62f);
        r.quadTo(w * 0.6f, h * 0.7f, w * 0.7f, h * 0.78f);
        c.drawPath(r, p);
    }
}
