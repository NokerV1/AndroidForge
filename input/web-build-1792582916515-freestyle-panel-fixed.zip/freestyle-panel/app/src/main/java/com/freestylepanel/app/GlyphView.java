package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Small line icons drawn in code (power, sliders, eye, aim reticles...). */
class GlyphView extends View {
    static final int POWER = 0, SLIDERS = 1, EYE = 2, EYE_OFF = 3, PIP = 4,
            AIM = 5, AIM_RED = 6, AIM_2X = 7, AIM_4X = 8, AIM_AWM = 9, FIRE = 10,
            CLOSE = 11, MINIMIZE = 12, GEAR = 13, SPARKLE = 14, BOLT = 15, HEX_AIM = 16,
            SKULL = 17, GAMEPAD = 18, CHIP = 19, LEAF = 20, BATTERY = 21, ANDROID = 22, CHECK = 23, HEX = 24, PHONE = 25;
    private final int type;
    private int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    GlyphView(Context c, int type, int color) {
        super(c);
        this.type = type;
        this.color = color;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    void setColor(int c) { color = c; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f, s * 0.085f));
        switch (type) {
            case POWER: {
                RectF r = new RectF(cx - .34f * s, cy - .30f * s, cx + .34f * s, cy + .38f * s);
                c.drawArc(r, -55, 290, false, p);
                c.drawLine(cx, cy - .42f * s, cx, cy - .06f * s, p);
                break;
            }
            case SLIDERS: {
                float[] ys = {-.26f, 0f, .26f};
                float[] ks = {-.12f, .16f, -.02f};
                for (int i = 0; i < 3; i++) {
                    c.drawLine(cx - .38f * s, cy + ys[i] * s, cx + .38f * s, cy + ys[i] * s, p);
                    c.drawLine(cx + ks[i] * s, cy + ys[i] * s - .1f * s, cx + ks[i] * s, cy + ys[i] * s + .1f * s, p);
                }
                break;
            }
            case EYE:
            case EYE_OFF: {
                Path e = new Path();
                e.moveTo(cx - .4f * s, cy);
                e.quadTo(cx, cy - .42f * s, cx + .4f * s, cy);
                e.quadTo(cx, cy + .42f * s, cx - .4f * s, cy);
                c.drawPath(e, p);
                c.drawCircle(cx, cy, .11f * s, p);
                if (type == EYE_OFF) c.drawLine(cx - .34f * s, cy + .34f * s, cx + .34f * s, cy - .34f * s, p);
                break;
            }
            case PIP: {
                c.drawRoundRect(new RectF(cx - .36f * s, cy - .3f * s, cx + .36f * s, cy + .3f * s), .08f * s, .08f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawRect(cx + .02f * s, cy - .2f * s, cx + .26f * s, cy - .02f * s, p);
                break;
            }
            case FIRE: {
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, .4f * s, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFF000000);
                p.setStrokeWidth(Math.max(2f, s * 0.07f));
                c.drawCircle(cx, cy, .2f * s, p);
                break;
            }
            case CLOSE: {
                p.setStrokeWidth(Math.max(2.5f, s * 0.1f));
                c.drawLine(cx - .3f * s, cy - .3f * s, cx + .3f * s, cy + .3f * s, p);
                c.drawLine(cx + .3f * s, cy - .3f * s, cx - .3f * s, cy + .3f * s, p);
                break;
            }
            case MINIMIZE: {
                c.drawLine(cx + .38f * s, cy - .38f * s, cx + .04f * s, cy - .04f * s, p);
                c.drawLine(cx + .04f * s, cy - .32f * s, cx + .04f * s, cy - .04f * s, p);
                c.drawLine(cx + .32f * s, cy - .04f * s, cx + .04f * s, cy - .04f * s, p);
                c.drawLine(cx - .38f * s, cy + .38f * s, cx - .04f * s, cy + .04f * s, p);
                c.drawLine(cx - .04f * s, cy + .32f * s, cx - .04f * s, cy + .04f * s, p);
                c.drawLine(cx - .32f * s, cy + .04f * s, cx - .04f * s, cy + .04f * s, p);
                break;
            }
            case GEAR: {
                c.drawCircle(cx, cy, .16f * s, p);
                c.drawCircle(cx, cy, .30f * s, p);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    c.drawLine(cx + (float) Math.cos(a) * .30f * s, cy + (float) Math.sin(a) * .30f * s,
                            cx + (float) Math.cos(a) * .42f * s, cy + (float) Math.sin(a) * .42f * s, p);
                }
                break;
            }
            case SPARKLE: {
                p.setStyle(Paint.Style.FILL);
                Path st = new Path();
                st.moveTo(cx, cy - .44f * s);
                st.quadTo(cx, cy, cx + .44f * s, cy);
                st.quadTo(cx, cy, cx, cy + .44f * s);
                st.quadTo(cx, cy, cx - .44f * s, cy);
                st.quadTo(cx, cy, cx, cy - .44f * s);
                c.drawPath(st, p);
                break;
            }
            case BOLT: {
                p.setStyle(Paint.Style.FILL);
                Path b = new Path();
                b.moveTo(cx + .12f * s, cy - .44f * s);
                b.lineTo(cx - .22f * s, cy + .06f * s);
                b.lineTo(cx - .02f * s, cy + .06f * s);
                b.lineTo(cx - .12f * s, cy + .44f * s);
                b.lineTo(cx + .22f * s, cy - .08f * s);
                b.lineTo(cx + .02f * s, cy - .08f * s);
                b.close();
                c.drawPath(b, p);
                break;
            }
            case HEX_AIM: {
                p.setStyle(Paint.Style.FILL);
                Path hx = new Path();
                for (int i = 0; i < 6; i++) {
                    double a = Math.PI / 3 * i;
                    float x = cx + (float) Math.cos(a) * .48f * s, y = cy + (float) Math.sin(a) * .42f * s;
                    if (i == 0) hx.moveTo(x, y); else hx.lineTo(x, y);
                }
                hx.close();
                c.drawPath(hx, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFF000000);
                p.setStrokeWidth(Math.max(1.5f, s * 0.06f));
                c.drawCircle(cx, cy, .17f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, .05f * s, p);
                break;
            }
            case HEX: {
                p.setStyle(Paint.Style.FILL);
                Path hx = new Path();
                for (int i = 0; i < 6; i++) {
                    double a = Math.PI / 3 * i;
                    float x = cx + (float) Math.cos(a) * .5f * s, y = cy + (float) Math.sin(a) * .44f * s;
                    if (i == 0) hx.moveTo(x, y); else hx.lineTo(x, y);
                }
                hx.close();
                c.drawPath(hx, p);
                break;
            }
            case CHECK: {
                p.setStrokeWidth(Math.max(2.5f, s * 0.1f));
                Path ck = new Path();
                ck.moveTo(cx - .3f * s, cy + .02f * s);
                ck.lineTo(cx - .08f * s, cy + .24f * s);
                ck.lineTo(cx + .32f * s, cy - .22f * s);
                c.drawPath(ck, p);
                break;
            }
            case GAMEPAD: {
                p.setStrokeWidth(Math.max(1.5f, s * 0.07f));
                c.drawRoundRect(new RectF(cx - .42f * s, cy - .24f * s, cx + .42f * s, cy + .26f * s), .2f * s, .2f * s, p);
                c.drawLine(cx - .26f * s, cy - .02f * s, cx - .1f * s, cy - .02f * s, p);
                c.drawLine(cx - .18f * s, cy - .1f * s, cx - .18f * s, cy + .06f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx + .14f * s, cy - .04f * s, .045f * s, p);
                c.drawCircle(cx + .26f * s, cy + .05f * s, .045f * s, p);
                break;
            }
            case SKULL: {
                p.setStrokeWidth(Math.max(1.8f, s * 0.08f));
                c.drawArc(new RectF(cx - .32f * s, cy - .42f * s, cx + .32f * s, cy + .22f * s), 150, 240, false, p);
                c.drawLine(cx - .2f * s, cy + .12f * s, cx - .2f * s, cy + .36f * s, p);
                c.drawLine(cx + .2f * s, cy + .12f * s, cx + .2f * s, cy + .36f * s, p);
                c.drawLine(cx - .2f * s, cy + .36f * s, cx + .2f * s, cy + .36f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx - .12f * s, cy - .08f * s, .07f * s, p);
                c.drawCircle(cx + .12f * s, cy - .08f * s, .07f * s, p);
                break;
            }
            case CHIP: {
                p.setStrokeWidth(Math.max(1.5f, s * 0.07f));
                c.drawRect(cx - .22f * s, cy - .22f * s, cx + .22f * s, cy + .22f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawRect(cx - .1f * s, cy - .1f * s, cx + .1f * s, cy + .1f * s, p);
                p.setStyle(Paint.Style.STROKE);
                for (int i = -1; i <= 1; i++) {
                    c.drawLine(cx + i * .14f * s, cy - .22f * s, cx + i * .14f * s, cy - .36f * s, p);
                    c.drawLine(cx + i * .14f * s, cy + .22f * s, cx + i * .14f * s, cy + .36f * s, p);
                    c.drawLine(cx - .22f * s, cy + i * .14f * s, cx - .36f * s, cy + i * .14f * s, p);
                    c.drawLine(cx + .22f * s, cy + i * .14f * s, cx + .36f * s, cy + i * .14f * s, p);
                }
                break;
            }
            case LEAF: {
                p.setStyle(Paint.Style.FILL);
                Path lf = new Path();
                lf.moveTo(cx - .3f * s, cy + .3f * s);
                lf.quadTo(cx - .4f * s, cy - .3f * s, cx + .32f * s, cy - .34f * s);
                lf.quadTo(cx + .4f * s, cy + .3f * s, cx - .3f * s, cy + .3f * s);
                lf.close();
                c.drawPath(lf, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFFFFFFFF);
                p.setStrokeWidth(Math.max(1.2f, s * 0.05f));
                c.drawLine(cx - .3f * s, cy + .3f * s, cx + .1f * s, cy - .1f * s, p);
                break;
            }
            case PHONE: {
                p.setStrokeWidth(Math.max(1.5f, s * 0.07f));
                c.drawRoundRect(new RectF(cx - .2f * s, cy - .38f * s, cx + .2f * s, cy + .38f * s), .07f * s, .07f * s, p);
                c.drawLine(cx - .06f * s, cy - .28f * s, cx + .06f * s, cy - .28f * s, p);
                break;
            }
            case BATTERY: {
                p.setStrokeWidth(Math.max(1.5f, s * 0.07f));
                c.drawRoundRect(new RectF(cx - .4f * s, cy - .2f * s, cx + .3f * s, cy + .2f * s), .07f * s, .07f * s, p);
                p.setStyle(Paint.Style.FILL);
                c.drawRect(cx + .32f * s, cy - .08f * s, cx + .4f * s, cy + .08f * s, p);
                c.drawRect(cx - .3f * s, cy - .1f * s, cx + .1f * s, cy + .1f * s, p);
                break;
            }
            default: {
                p.setStrokeWidth(Math.max(1.5f, s * 0.07f));
                float r = .34f * s;
                c.drawCircle(cx, cy, r, p);
                if (type == AIM) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy, .08f * s, p);
                } else if (type == AIM_RED) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy, .06f * s, p);
                    p.setStyle(Paint.Style.STROKE);
                    c.drawLine(cx, cy - r, cx, cy - r + .1f * s, p);
                    c.drawLine(cx, cy + r, cx, cy + r - .1f * s, p);
                } else if (type == AIM_2X) {
                    c.drawCircle(cx, cy, .14f * s, p);
                } else if (type == AIM_4X) {
                    c.drawLine(cx - r, cy, cx - .1f * s, cy, p);
                    c.drawLine(cx + r, cy, cx + .1f * s, cy, p);
                    c.drawLine(cx, cy - r, cx, cy - .1f * s, p);
                    c.drawLine(cx, cy + r, cx, cy + .1f * s, p);
                } else {
                    c.drawLine(cx - r - .08f * s, cy, cx + r + .08f * s, cy, p);
                    c.drawLine(cx, cy - r - .08f * s, cx, cy + r + .08f * s, p);
                }
            }
        }
    }
}
