package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Original decorative figure: a plain standing silhouette (drawn in code). */
class SilhouetteView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    SilhouetteView(Context c) { super(c); p.setColor(0xFFF2F2F2); }

    @Override protected void onDraw(Canvas c) {
        float H = getHeight() * 0.94f, top = getHeight() * 0.03f, cx = getWidth() / 2f;
        // head + cap
        c.drawCircle(cx, top + .085f * H, .045f * H, p);
        c.drawArc(new RectF(cx - .055f * H, top + .02f * H, cx + .055f * H, top + .1f * H), 180, 180, true, p);
        c.drawRoundRect(new RectF(cx - .11f * H, top + .068f * H, cx - .01f * H, top + .08f * H), 4, 4, p);
        // torso
        c.drawRoundRect(new RectF(cx - .08f * H, top + .135f * H, cx + .08f * H, top + .5f * H), .03f * H, .03f * H, p);
        // arms
        c.drawRoundRect(new RectF(cx - .105f * H, top + .15f * H, cx - .07f * H, top + .47f * H), .02f * H, .02f * H, p);
        c.drawRoundRect(new RectF(cx + .07f * H, top + .15f * H, cx + .105f * H, top + .47f * H), .02f * H, .02f * H, p);
        // legs
        c.drawRoundRect(new RectF(cx - .082f * H, top + .48f * H, cx - .004f * H, top + .91f * H), .015f * H, .015f * H, p);
        c.drawRoundRect(new RectF(cx + .004f * H, top + .48f * H, cx + .082f * H, top + .91f * H), .015f * H, .015f * H, p);
        // shoes
        c.drawOval(new RectF(cx - .1f * H, top + .9f * H, cx - .0f * H, top + .95f * H), p);
        c.drawOval(new RectF(cx + .0f * H, top + .9f * H, cx + .1f * H, top + .95f * H), p);
    }
}
