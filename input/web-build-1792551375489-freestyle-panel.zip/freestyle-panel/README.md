# Freestyle Panel (recreated from screen recording)

Pure-Java Android app, no external libraries. minSdk 26, targetSdk 34, package `com.freestylepanel.app`.

## Build the APK
GitHub: create a repo, upload this folder's contents, Actions tab > "Build APK" > download `FreestylePanel-APK`.
Android Studio: open the folder, Build > Build APK(s).

## What's in it
- Start tab: big Start button (red = off, green = on), show/hide floating icon, icon opacity.
- Floating icon: draggable overlay (needs "Display over other apps"); tap it to open the sensitivity panel as a window over the game (X or tap outside to close).
- Pressing Start opens the floating panel window (draggable header, minimize to icon, close). Tabs: Main (HH POINT selector, saved only), Configs (sensitivity sets), I.A (not available), Optimizar (RAM readout, battery settings).
- Sensitivity tab: 100X / 200X chooser, DPI tabs (No DPI, -600, +600, +1000), sensitivity cards, per-set detail page with Cursor/Pointer speed.

## Notes
- Header art is original (a drawn hooded silhouette), not the original logo.
- Sensitivity numbers: values visible in the recording are exact; AWM values and unseen sets are placeholders. Edit `DATA` in MainActivity.java.
- 100X and 200X currently show the same sets (only one set was visible in the recording).
