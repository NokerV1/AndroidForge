# Freestyle Panel Android project

This project wraps the existing `freestyle_panel.html` in an Android WebView so AndroidForge/Gradle can build it as an APK.

## Build requirements
- JDK 17
- Android SDK with Android SDK Platform 35 and Build Tools installed
- Gradle 8.9 or a compatible Gradle 8.x installation (Android Gradle Plugin 8.7.3)

## Build
From the project root:

```bash
gradle assembleDebug
```

The APK should be created at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

If you use the Gradle wrapper in your environment, you can run `./gradlew assembleDebug` instead. This ZIP does not bundle a Gradle wrapper JAR.

## Notes
- The HTML file is stored in `app/src/main/assets/freestyle_panel.html`.
- JavaScript and DOM storage are enabled for the panel UI.
- This is a basic WebView wrapper. Features that require native Android APIs or remote network access may need additional implementation.
