package com.freestylepanel.app;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/** The floating window: header (drag / minimize / close), tabs (Main, Configs, I.A, Optimizar) and their pages. */
class PanelWindow extends LinearLayout {
    interface Host {
        void minimize();
        void exit();
        void move(float dx, float dy);
    }

    static final int BG = 0xFF000000, FG = 0xFFFFFFFF, MUTE = 0xFF8E8E8E, EDGE = 0xFF2E2E2E, GREEN = 0xFF1DD18B;
    private final Host host;
    private final float density;
    private final SharedPreferences sp;
    private final FrameLayout content;
    private final LinearLayout[] tabs = new LinearLayout[4];
    private final TextView[] tabText = new TextView[4];
    private final GlyphView[] tabIcon = new GlyphView[4];
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int current = -1;
    private int target;

    PanelWindow(Context c, Host host) {
        super(c);
        this.host = host;
        density = c.getResources().getDisplayMetrics().density;
        sp = c.getSharedPreferences("fp", Context.MODE_PRIVATE);
        target = sp.getInt("hhpoint", 0);
        setOrientation(VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(BG);
        bg.setCornerRadius(dp(20));
        setBackground(bg);
        setClipToOutline(true);

        addView(header(), new LayoutParams(-1, dp(46)));

        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        String[] names = {"Main", "Configs", "I.A", "Optimizar"};
        int[] icons = {GlyphView.SKULL, GlyphView.GEAR, GlyphView.SPARKLE, GlyphView.BOLT};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout t = new LinearLayout(c);
            t.setGravity(Gravity.CENTER);
            GlyphView g = new GlyphView(c, icons[i], FG);
            t.addView(g, new LayoutParams(dp(18), dp(18)));
            tabIcon[i] = g;
            TextView tx = text(names[i], 14, FG);
            tx.setPadding(dp(8), 0, 0, 0);
            t.addView(tx);
            tabText[i] = tx;
            tabs[i] = t;
            t.setOnClickListener(v -> showTab(idx));
            row.addView(t, new LayoutParams(0, dp(38), 1f));
        }
        addView(row, new LayoutParams(-1, -2));
        View line = new View(c);
        line.setBackgroundColor(EDGE);
        addView(line, new LayoutParams(-1, dp(2)));
        content = new FrameLayout(c);
        addView(content, new LayoutParams(-1, 0, 1f));
        showTab(0);
    }

    // ------------------------------------------------------------ helpers
    private int dp(int v) { return (int) (v * density + .5f); }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private GradientDrawable shape(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }

    private LinearLayout vl() {
        LinearLayout l = new LinearLayout(getContext());
        l.setOrientation(VERTICAL);
        return l;
    }

    /** White hexagon badge with a dark icon inside. */
    private View hexIcon(int glyph) {
        FrameLayout f = new FrameLayout(getContext());
        f.addView(new GlyphView(getContext(), GlyphView.HEX, FG), new FrameLayout.LayoutParams(-1, -1));
        f.addView(new GlyphView(getContext(), glyph, BG), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        f.setLayoutParams(new LayoutParams(dp(36), dp(32)));
        return f;
    }

    private View hexText(String a, String b) {
        FrameLayout f = new FrameLayout(getContext());
        f.addView(new GlyphView(getContext(), GlyphView.HEX, FG), new FrameLayout.LayoutParams(-1, -1));
        TextView t = text(a + "\n" + b, 7.5f, BG);
        t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setLineSpacing(0, .85f);
        f.addView(t, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        f.setLayoutParams(new LayoutParams(dp(36), dp(32)));
        return f;
    }

    private TextView chip(boolean on) {
        TextView c = text(on ? "ENABLED" : "DISABLED", 11.5f, on ? 0xFF146C43 : 0xFFB3261E);
        c.setBackground(shape(on ? 0xFFD4F5E4 : 0xFFFFD6DC, 10, 0, 0));
        c.setPadding(dp(11), dp(6), dp(11), dp(6));
        return c;
    }

    private void paintChip(TextView c, boolean on) {
        c.setText(on ? "ENABLED" : "DISABLED");
        c.setTextColor(on ? 0xFF146C43 : 0xFFB3261E);
        c.setBackground(shape(on ? 0xFFD4F5E4 : 0xFFFFD6DC, 10, 0, 0));
        c.setPadding(dp(11), dp(6), dp(11), dp(6));
    }

    private Switch makeSwitch(boolean on) {
        Switch sw = new Switch(getContext());
        int[][] st = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(st, new int[]{FG, FG}));
        sw.setTrackTintList(new ColorStateList(st, new int[]{GREEN, 0xFF5F5F5F}));
        sw.setChecked(on);
        return sw;
    }

    private FrameLayout checkbox(boolean filled, boolean checked) {
        FrameLayout f = new FrameLayout(getContext());
        paintBox(f, filled, checked);
        return f;
    }

    private void paintBox(FrameLayout f, boolean filled, boolean checked) {
        f.removeAllViews();
        f.setBackground(checked || filled ? shape(FG, 6, 0, 0) : shape(0, 6, FG, 2));
        if (checked) f.addView(new GlyphView(getContext(), GlyphView.CHECK, BG), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
    }

    // ------------------------------------------------------------ header
    private View header() {
        final Context c = getContext();
        FrameLayout h = new FrameLayout(c);
        h.setBackgroundColor(FG);
        TextView title = text("FREESTYLE PANEL", 16, 0xFF111111);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.START);
        tp.leftMargin = dp(16);
        h.addView(title, tp);
        h.addView(new BannerView(c), new FrameLayout.LayoutParams(dp(120), -1, Gravity.CENTER));

        LinearLayout right = new LinearLayout(c);
        right.setGravity(Gravity.CENTER_VERTICAL);
        right.addView(iconButton(GlyphView.MINIMIZE, v -> host.minimize()), new LayoutParams(dp(40), dp(40)));
        right.addView(iconButton(GlyphView.CLOSE, v -> host.exit()), new LayoutParams(dp(40), dp(40)));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -1, Gravity.END);
        rp.rightMargin = dp(6);
        h.addView(right, rp);

        h.setOnTouchListener(new OnTouchListener() {
            float lx, ly;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: lx = e.getRawX(); ly = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        host.move(e.getRawX() - lx, e.getRawY() - ly);
                        lx = e.getRawX(); ly = e.getRawY();
                        return true;
                    default: return true;
                }
            }
        });
        return h;
    }

    private FrameLayout iconButton(int glyph, OnClickListener l) {
        FrameLayout f = new FrameLayout(getContext());
        f.addView(new GlyphView(getContext(), glyph, 0xFF111111), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setOnClickListener(l);
        return f;
    }

    // ------------------------------------------------------------ tabs
    private void showTab(int i) {
        if (i == current) return;
        current = i;
        for (int k = 0; k < 4; k++) {
            boolean sel = k == i;
            tabs[k].setBackground(sel ? shape(FG, 6, 0, 0) : null);
            tabText[k].setTextColor(sel ? BG : FG);
            tabIcon[k].setColor(sel ? BG : FG);
        }
        View page = i == 0 ? mainPage() : i == 1 ? configsPage() : i == 2 ? aiPage() : optimizePage();
        setPage(page);
    }

    private void setPage(View page) {
        content.removeAllViews();
        page.setAlpha(0f);
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
        page.animate().alpha(1f).setDuration(160).start();
    }

    private ScrollView scroller(View child) {
        ScrollView sv = new ScrollView(getContext());
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        sv.addView(child);
        return sv;
    }

    // ------------------------------------------------------------ Main
    private View mainPage() {
        final Context c = getContext();
        LinearLayout root = new LinearLayout(c);
        LinearLayout left = vl();
        left.setPadding(dp(10), dp(8), dp(6), dp(6));
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(new GlyphView(c, GlyphView.HEX_AIM, FG), new LayoutParams(dp(34), dp(30)));
        TextView t = text("HH POINT", 18, FG);
        t.setPadding(dp(12), 0, 0, 0);
        head.addView(t);
        left.addView(head, new LayoutParams(-1, dp(40)));
        String[] names = {"HEAD", "NECK", "FULL BODY"};
        final TextView[] btns = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView b = text(names[i], 17, FG);
            b.setLetterSpacing(0.18f);
            b.setGravity(Gravity.CENTER);
            btns[i] = b;
            b.setOnClickListener(v -> {
                target = idx;
                sp.edit().putInt("hhpoint", idx).apply();
                paint(btns);
            });
            LayoutParams lp = new LayoutParams(-1, dp(48));
            lp.topMargin = dp(8);
            left.addView(b, lp);
        }
        paint(btns);
        TextView note = text("Saved selection only. This app does not aim or control any game.", 10, MUTE);
        note.setPadding(dp(4), dp(8), dp(4), 0);
        left.addView(note);
        root.addView(left, new LayoutParams(0, -1, 1f));
        root.addView(new SilhouetteView(c), new LayoutParams(0, -1, 1f));
        return root;
    }

    private void paint(TextView[] btns) {
        for (int i = 0; i < btns.length; i++) {
            boolean sel = i == target;
            btns[i].setBackground(shape(BG, 26, sel ? FG : 0xFF333333, sel ? 2 : 3));
        }
    }

    // ------------------------------------------------------------ Configs
    private View configsPage() {
        LinearLayout col = vl();
        col.setPadding(dp(14), dp(6), dp(14), dp(14));
        col.addView(checkRow("More Sensitive", "cfg_more"));
        col.addView(checkRow("Light Touch", "cfg_light"));
        col.addView(checkRow("Control Sight", "cfg_sight"));
        col.addView(switchRow(GlyphView.AIM, "Trick Button", "cfg_trick"));
        col.addView(switchRow(GlyphView.AIM_AWM, "Pro Crosshair", "cfg_cross"));

        LinearLayout sens = new LinearLayout(getContext());
        sens.setGravity(Gravity.CENTER_VERTICAL);
        sens.setPadding(dp(4), dp(10), dp(4), dp(10));
        sens.addView(hexIcon(GlyphView.SLIDERS));
        TextView st = text("Sensitivity values", 17, FG);
        st.setPadding(dp(14), 0, 0, 0);
        sens.addView(st, new LayoutParams(0, -2, 1f));
        sens.addView(text("→", 20, FG));
        sens.setOnClickListener(v -> openSensitivity());
        LayoutParams sp1 = new LayoutParams(-1, -2);
        sp1.topMargin = dp(8);
        col.addView(sens, sp1);

        TextView note = text("Switches here are saved settings only. Freestyle Panel does not change or control any game.", 10, MUTE);
        note.setPadding(dp(4), dp(10), dp(4), 0);
        col.addView(note);
        return scroller(col);
    }

    private View checkRow(String label, final String key) {
        boolean on = sp.getBoolean(key, false);
        LinearLayout r = new LinearLayout(getContext());
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(9), dp(4), dp(9));
        final FrameLayout box = checkbox(false, on);
        r.addView(box, new LayoutParams(dp(28), dp(28)));
        TextView t = text(label, 17, FG);
        t.setPadding(dp(16), 0, 0, 0);
        r.addView(t, new LayoutParams(0, -2, 1f));
        final TextView chip = chip(on);
        r.addView(chip);
        r.setOnClickListener(v -> {
            boolean now = !sp.getBoolean(key, false);
            sp.edit().putBoolean(key, now).apply();
            paintBox(box, false, now);
            paintChip(chip, now);
        });
        return r;
    }

    private View switchRow(int glyph, String label, final String key) {
        boolean on = sp.getBoolean(key, false);
        LinearLayout r = new LinearLayout(getContext());
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(9), dp(4), dp(9));
        r.addView(hexIcon(glyph));
        TextView t = text(label, 17, FG);
        t.setPadding(dp(14), 0, 0, 0);
        r.addView(t, new LayoutParams(0, -2, 1f));
        final TextView chip = chip(on);
        r.addView(chip);
        Switch sw = makeSwitch(on);
        LayoutParams lp = new LayoutParams(-2, -2);
        lp.leftMargin = dp(10);
        r.addView(sw, lp);
        sw.setOnCheckedChangeListener((v, checked) -> {
            sp.edit().putBoolean(key, checked).apply();
            paintChip(chip, checked);
        });
        return r;
    }

    /** Shows the sensitivity sets inside the Configs tab, with a back row. */
    private void openSensitivity() {
        LinearLayout col = vl();
        final SensitivityPanel panel = new SensitivityPanel(getContext(), false);
        TextView back = text("‹  Configs", 15, FG);
        back.setPadding(dp(16), dp(10), dp(16), dp(6));
        back.setOnClickListener(v -> { if (!panel.back()) setPage(configsPage()); });
        col.addView(back, new LayoutParams(-1, -2));
        col.addView(panel, new LayoutParams(-1, 0, 1f));
        setPage(col);
    }

    // ------------------------------------------------------------ I.A
    private View aiPage() {
        LinearLayout l = vl();
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(24), dp(16), dp(24), dp(16));
        l.addView(new GlyphView(getContext(), GlyphView.SPARKLE, MUTE), new LayoutParams(dp(30), dp(30)));
        TextView t = text("I.A is not available in this build.", 15, FG);
        t.setPadding(0, dp(12), 0, dp(4));
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        TextView s = text("This app only shows reference values and does not control any game.", 12, MUTE);
        s.setGravity(Gravity.CENTER);
        l.addView(s);
        return l;
    }

    // ------------------------------------------------------------ Optimizar
    private View optimizePage() {
        final Context c = getContext();
        LinearLayout col = vl();
        col.setPadding(dp(14), dp(8), dp(14), dp(14));

        // top row: gamepad badge, logo tile, apply button
        FrameLayout top = new FrameLayout(c);
        top.addView(hexIcon(GlyphView.GAMEPAD), new FrameLayout.LayoutParams(dp(36), dp(32), Gravity.CENTER_VERTICAL | Gravity.START));
        FrameLayout tile = new FrameLayout(c);
        tile.setBackground(shape(FG, 18, 0, 0));
        tile.addView(new GlyphView(c, GlyphView.POWER, BG), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        top.addView(tile, new FrameLayout.LayoutParams(dp(66), dp(60), Gravity.CENTER));
        FrameLayout apply = new FrameLayout(c);
        apply.setBackground(shape(0xFF1C1C1C, 12, 0, 0));
        apply.addView(new GlyphView(c, GlyphView.CHECK, 0xFF9A9A9A), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        apply.setOnClickListener(v -> { applyRefresh(sp.getInt("fpsSel", 0)); toast("Applied"); });
        top.addView(apply, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER_VERTICAL | Gravity.END));
        col.addView(top, new LayoutParams(-1, dp(64)));

        // Improve FPS
        LinearLayout hdr = new LinearLayout(c);
        hdr.setGravity(Gravity.CENTER_VERTICAL);
        hdr.setPadding(0, dp(10), 0, dp(6));
        hdr.addView(hexText("120", "FPS"));
        TextView ht = text("Improve FPS", 18, FG);
        ht.setPadding(dp(14), 0, 0, 0);
        hdr.addView(ht);
        col.addView(hdr);

        LinearLayout fpsRow = new LinearLayout(c);
        LinearLayout list = vl();
        final int[] hz = {90, 120, 144, 240};
        final FrameLayout[] boxes = new FrameLayout[4];
        for (int i = 0; i < 4; i++) {
            final int idx = i + 1;
            LinearLayout r = new LinearLayout(c);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(4), dp(7), dp(4), dp(7));
            boxes[i] = checkbox(true, sp.getInt("fpsSel", 0) == idx);
            r.addView(boxes[i], new LayoutParams(dp(26), dp(26)));
            TextView t = text(hz[i] + " FPS", 17, FG);
            t.setGravity(Gravity.END);
            r.addView(t, new LayoutParams(0, -2, 1f));
            r.setOnClickListener(v -> {
                int now = sp.getInt("fpsSel", 0) == idx ? 0 : idx;
                sp.edit().putInt("fpsSel", now).apply();
                for (int k = 0; k < 4; k++) paintBox(boxes[k], true, now == k + 1);
                applyRefresh(now);
            });
            list.addView(r, new LayoutParams(-1, dp(40)));
        }
        fpsRow.addView(list, new LayoutParams(0, -2, 1f));
        fpsRow.addView(new GripView(c), new LayoutParams(0, dp(150), 1f));
        col.addView(fpsRow);

        col.addView(optRow(GlyphView.BOLT, "Reduce crashes", "opt_crash", on -> {
            if (!on) return;
            try {
                c.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.getPackageName()))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e) {
                try { c.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (Exception ignored) {}
            }
        }));
        col.addView(optRow(GlyphView.CHIP, "Optimize RAM", "opt_ram", on -> {
            if (!on) return;
            System.gc();
            toast("Memory refreshed. " + freeRam());
        }));
        final Switch[] clearSw = new Switch[1];
        View clear = optRow(GlyphView.LEAF, "Clear Memory", "opt_clear", on -> {
            if (!on) return;
            int n = clearBackground();
            toast(n > 0 ? "Closed background apps (" + n + " checked). " + freeRam() : "Nothing to clear. " + freeRam());
            ui.postDelayed(() -> { if (clearSw[0] != null) clearSw[0].setChecked(false); }, 900);
        });
        clearSw[0] = (Switch) ((LinearLayout) clear).getChildAt(2);
        col.addView(clear);

        // footer: Android version + battery
        LinearLayout foot = new LinearLayout(c);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(16), 0, 0);
        foot.addView(text("Android", 14, FG));
        TextView ver = text(" " + Build.VERSION.RELEASE + " ", 22, FG);
        ver.setTypeface(null, Typeface.BOLD);
        foot.addView(ver);
        foot.addView(hexIcon(GlyphView.PHONE));
        View sp2 = new View(c);
        foot.addView(sp2, new LayoutParams(dp(16), 1));
        foot.addView(hexIcon(GlyphView.BATTERY));
        TextView bat = text("  " + batteryPct() + "% ", 24, FG);
        bat.setTypeface(null, Typeface.BOLD);
        foot.addView(bat);
        foot.addView(text("remaining", 14, FG));
        col.addView(foot);
        return scroller(col);
    }

    private interface OnToggle { void run(boolean on); }

    private View optRow(int glyph, String label, final String key, final OnToggle action) {
        LinearLayout r = new LinearLayout(getContext());
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(8), dp(4), dp(8));
        r.addView(hexIcon(glyph));
        TextView t = text(label, 17, FG);
        t.setPadding(dp(14), 0, 0, 0);
        r.addView(t, new LayoutParams(0, -2, 1f));
        Switch sw = makeSwitch(sp.getBoolean(key, false));
        r.addView(sw);
        sw.setOnCheckedChangeListener((v, checked) -> {
            sp.edit().putBoolean(key, checked).apply();
            action.run(checked);
        });
        return r;
    }

    // ------------------------------------------------------------ real actions
    private String freeRam() {
        ActivityManager am = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return "Free RAM " + (mi.availMem / (1024 * 1024)) + " MB of " + (mi.totalMem / (1024 * 1024)) + " MB";
    }

    private int batteryPct() {
        try {
            Intent b = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            return level < 0 ? 0 : Math.round(level * 100f / scale);
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Asks Android to end cached background processes of other launcher apps (never touches the foreground app). */
    private int clearBackground() {
        Context c = getContext();
        int n = 0;
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager pm = c.getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
            for (ResolveInfo ri : apps) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName())) continue;
                am.killBackgroundProcesses(pkg);
                n++;
            }
        } catch (Throwable ignored) {}
        System.gc();
        return n;
    }

    /**
     * Best-effort: asks Android for a minimum/peak display refresh rate. Needs the "Modify system settings" permission,
     * and some phone makers ignore these keys.
     */
    private void applyRefresh(int sel) {
        Context c = getContext();
        int[] hz = {0, 90, 120, 144, 240};
        try {
            if (!Settings.System.canWrite(c)) {
                toast("Allow \"Modify system settings\" to apply the refresh rate.");
                c.startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.getPackageName()))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            }
            ContentResolver cr = c.getContentResolver();
            if (!sp.contains("origMin")) {
                sp.edit().putFloat("origMin", Settings.System.getFloat(cr, "min_refresh_rate", 0f))
                        .putFloat("origPeak", Settings.System.getFloat(cr, "peak_refresh_rate", 0f)).apply();
            }
            if (sel == 0) {
                Settings.System.putFloat(cr, "min_refresh_rate", sp.getFloat("origMin", 0f));
                Settings.System.putFloat(cr, "peak_refresh_rate", sp.getFloat("origPeak", 0f));
            } else {
                Settings.System.putFloat(cr, "min_refresh_rate", hz[sel]);
                Settings.System.putFloat(cr, "peak_refresh_rate", hz[sel]);
            }
        } catch (Throwable ignored) {}
    }
}
