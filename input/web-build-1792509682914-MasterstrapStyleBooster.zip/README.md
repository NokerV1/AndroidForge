# Masterstrap-style Android Booster UI

A native Kotlin Android UI inspired by the uploaded reference video: pale background, Masterstrap-like header, stacked settings cards, dropdowns, toggles, and bottom navigation.

This is an original implementation inspired by the layout, not the original Masterstrap app. The controls are a UI demo and store no Roblox changes; normal Android apps generally cannot apply arbitrary Roblox FastFlags or guarantee FPS increases.

Build with AndroidForge by uploading this ZIP. Java and Kotlin targets are both set to JVM 17 to address the prior build error.
