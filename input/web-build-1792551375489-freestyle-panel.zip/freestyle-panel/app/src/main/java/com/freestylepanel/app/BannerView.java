package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Original header art: a hooded silhouette on white (drawn in code). */
class BannerView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    BannerView(Context c) { super(c); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        c.drawColor(0xFFFFFFFF);
        float cx = w / 2f;
        Path hood = new Path();
        hood.moveTo(cx, -h * 0.1f);
        hood.cubicTo(cx + w * 0.10f, h * 0.15f, cx + w * 0.16f, h * 0.55f, cx + w * 0.30f, h);
        hood.lineTo(cx - w * 0.30f, h);
        hood.cubicTo(cx - w * 0.16f, h * 0.55f, cx - w * 0.10f, h * 0.15f, cx, -h * 0.1f);
        hood.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF2B2B2B);
        c.drawPath(hood, p);
        p.setColor(0xFF111111);
        c.drawOval(new RectF(cx - w * 0.095f, h * 0.18f, cx + w * 0.095f, h * 0.95f), p);
        p.setColor(0xFF8C8C8C);
        c.drawOval(new RectF(cx - w * 0.055f, h * 0.50f, cx + w * 0.055f, h * 0.90f), p);
        p.setColor(0xFF2B2B2B);
        c.drawRect(cx - w * 0.085f, h * 0.44f, cx + w * 0.085f, h * 0.52f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(getResources().getDisplayMetrics().density * 1.5f);
        p.setColor(0xFF000000);
        c.drawPath(hood, p);
    }
}
