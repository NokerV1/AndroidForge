# Neon Roblox Booster (Android)

Native Kotlin Android project. The Gradle config explicitly targets Java 17 for both Java and Kotlin, fixing the reported inconsistent JVM target error.

## Build with AndroidForge
Upload this ZIP as the source ZIP and run the debug APK build. If the builder still fails, inspect the latest compile log.

## Limits
The display Hz readout is screen refresh rate, not live Roblox FPS. This app doesn't patch Roblox, require root, or guarantee FPS gains.
