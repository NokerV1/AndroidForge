# Freestyle Panel Android project

This project wraps the panel in a WebView and provides an Android floating overlay service.

## How to use
1. Build and install the APK.
2. Open Freestyle Panel.
3. Tap **START FLOATING PANEL**.
4. Android opens **Display over other apps** settings. Enable permission for Freestyle Panel and return.
5. The panel appears above other apps. Drag it by its white title bar. Tap X to close it.
6. To start it again, open the app and tap Start.

## Build requirements
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 and compatible Gradle 8.x

Build with `gradle assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

This provides a visual floating panel only. It does not interact with or modify other apps or games.
