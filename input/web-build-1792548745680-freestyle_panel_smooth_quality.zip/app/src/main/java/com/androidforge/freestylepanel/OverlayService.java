package com.androidforge.freestylepanel;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View overlay;
    private WindowManager.LayoutParams params;
    private WebView webView;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
    }

    private void createOverlay() {
        FrameLayout shell = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.BLACK);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.DKGRAY);
        shell.setBackground(bg);
        shell.setClipToOutline(true);

        LinearLayoutCompat header = new LinearLayoutCompat(this);
        header.setBackgroundColor(Color.WHITE);
        header.setPadding(dp(12), dp(4), dp(4), dp(4));
        header.setOrientation(LinearLayoutCompat.HORIZONTAL);
        TextViewCompat title = new TextViewCompat(this);
        title.setText("FREESTYLE PANEL");
        title.setTextColor(Color.BLACK);
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(title, new LinearLayoutCompat.LayoutParams(0, dp(42), 1));
        ImageButton close = new ImageButton(this);
        close.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        close.setBackgroundColor(Color.TRANSPARENT);
        header.addView(close, new LinearLayoutCompat.LayoutParams(dp(42), dp(42)));
        shell.addView(header, new FrameLayout.LayoutParams(-1, dp(50), Gravity.TOP));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(-1, -1);
        webLp.topMargin = dp(50);
        shell.addView(webView, webLp);
        webView.loadUrl("file:///android_asset/freestyle_panel.html");
        webView.postDelayed(() -> {
            if (webView != null) {
                webView.evaluateJavascript(
                    "(function(){document.querySelector('.hero')?.remove();document.querySelector('.head')?.remove();document.querySelector('.bar')?.remove();document.querySelector('.float')?.remove();document.querySelector('.row')?.remove();document.querySelector('.opacity')?.remove();document.querySelector('.arc')?.remove();document.body.style.display='block';document.body.style.background='#000';document.querySelector('.panel').style.cssText='position:relative;left:0;top:0;width:100%;height:100%;margin:0;border-radius:0;box-shadow:none';document.querySelector('.tabs').style.padding='5px';document.querySelectorAll('.tab').forEach(x=>x.style.fontSize='12px');document.querySelector('.body').style.padding='8px';document.querySelectorAll('.opt').forEach(x=>x.style.height='50px');})();",
                    null);
            }
        }, 500);

        close.setOnClickListener(v -> stopSelf());
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y;
                    downX = e.getRawX(); downY = e.getRawY(); return true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(e.getRawX() - downX);
                    params.y = startY + (int)(e.getRawY() - downY);
                    try { windowManager.updateViewLayout(overlay, params); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int overlayWidth = Math.min(dp(420), screenWidth - dp(20));
        params = new WindowManager.LayoutParams(overlayWidth, dp(420), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = dp(110);
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;
        overlay = shell;
        windowManager.addView(overlay, params);
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) {}
        }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    // Tiny local helper views avoid adding third-party dependencies.
    private static class LinearLayoutCompat extends android.widget.LinearLayout {
        LinearLayoutCompat(android.content.Context c) { super(c); }
    }
    private static class TextViewCompat extends android.widget.TextView {
        TextViewCompat(android.content.Context c) { super(c); }
    }
}
