package com.masterstrap.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

final class Root {
    private Root() {}

    /** Runs a command as root. Returns trimmed output, or null if root is unavailable or the command failed. */
    static String run(String cmd) {
        try {
            Process pr = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            InputStream in = pr.getInputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            if (!pr.waitFor(15, TimeUnit.SECONDS)) { pr.destroy(); return null; }
            return pr.exitValue() == 0 ? bo.toString("UTF-8").trim() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    static boolean available() {
        String id = run("id -u");
        return id != null && id.endsWith("0");
    }
}
