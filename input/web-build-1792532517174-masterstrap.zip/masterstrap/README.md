# Masterstrap (recreated from screen recording)

Pure-Java Android app (no external libraries). minSdk 26, targetSdk 34.

## Build the APK
**GitHub (no install):** create a new repo, upload this folder's contents, open the *Actions* tab,
run "Build APK" and download the `Masterstrap-APK` artifact (debug-signed, installable).

**Android Studio:** open this folder, then Build > Build APK(s).

## Notes
- Screens: FastFlag, FF Settings (+Mods), Game Mode, Preset, FastFlag Editor, Settings & About, launch animation.
- Rocket button saves your toggles, builds a FastFlag JSON, runs Safe Boosts (wake lock, low-latency Wi-Fi, thermal check) and launches Roblox.
- Only a handful of toggles are mapped to real FastFlag names (see `computeFlags()` in MainActivity.java). Edit freely.
- Writing flags into Roblox needs root; the path (`ROOT_DIR_FMT`) is an unverified guess. Without root the JSON is kept in app storage and can be exported from the editor.
- Pro/crown items are locked and license activation is a stub.
