package com.masterstrap.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;
import java.util.Random;

/** Full-screen "launch environment" animation: blue rain + rocket that lifts off. */
class LaunchOverlay extends View {
    private final Paint bg = new Paint();
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] x = new float[70], y = new float[70], len = new float[70], speed = new float[70];
    private final Random r = new Random();
    private long last = System.nanoTime();
    private long launchAt = 0;
    private String message = "Launch environment ready...";

    LaunchOverlay(Context c) {
        super(c);
        setClickable(true);
        float d = getResources().getDisplayMetrics().density;
        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        text.setTextSize(d * 17);
        line.setStrokeWidth(d * 2);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    void setMessage(String m) { message = m; }

    void launch() { launchAt = System.nanoTime(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xFF050B18, 0xFF0A2347, Shader.TileMode.CLAMP));
        for (int i = 0; i < x.length; i++) reset(i, true);
    }

    private void reset(int i, boolean anywhere) {
        int w = getWidth(), h = getHeight();
        x[i] = r.nextFloat() * w;
        len[i] = h * (0.04f + r.nextFloat() * 0.12f);
        speed[i] = h * (0.35f + r.nextFloat() * 0.9f);
        y[i] = anywhere ? r.nextFloat() * h : -len[i];
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bg);
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1e9f, 0.05f);
        last = now;
        float t = launchAt == 0 ? 0 : (now - launchAt) / 1e9f;
        float boost = 1f + t * 4f;
        for (int i = 0; i < x.length; i++) {
            y[i] += speed[i] * dt * boost;
            if (y[i] > h) reset(i, false);
            line.setColor(i % 3 == 0 ? 0xAA1E9BF0 : 0x661E9BF0);
            c.drawLine(x[i], y[i], x[i], y[i] + len[i] * boost, line);
        }
        float bob = launchAt == 0 ? (float) Math.sin(now / 4e8) * h * 0.008f : -(t * t) * h * 0.9f;
        Rocket.draw(c, w / 2f, h * 0.42f + bob, w * 0.13f, true);
        c.drawText(message, w / 2f, h * 0.85f, text);
        postInvalidateOnAnimation();
    }
}
