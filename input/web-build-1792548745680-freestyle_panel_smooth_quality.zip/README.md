# Freestyle Panel — polished floating Android UI

This project wraps the supplied panel HTML in a WebView and includes an Android overlay service.

## Included improvements
- Compact floating window that adapts to the device width
- Drag handle in the title bar
- Close control and start/stop screen
- Smooth entrance, tab, and button transitions
- Reduced-motion accessibility support
- No third-party runtime dependencies

## Install and use
1. Build and install the APK.
2. Open Freestyle Panel and tap **START FLOATING PANEL**.
3. Enable **Display over other apps** in Android settings.
4. Return to the app; the panel will appear over other apps.
5. Drag the white title bar to move the window; tap X to close it.

## Build requirements
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 with a compatible Gradle 8.x version

Run `gradle assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Note: this is a UI overlay. It does not read, automate, or modify other apps or games. The project source has not been compiled on a device in this environment, so test the build in your AndroidForge setup.
