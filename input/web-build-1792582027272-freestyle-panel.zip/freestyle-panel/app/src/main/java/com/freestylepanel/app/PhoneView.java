package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Original decorative drawing: a phone held in two hands (landscape). */
class PhoneView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    PhoneView(Context c) { super(c); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF0F0F0);
        c.drawRoundRect(new RectF(w * .16f, h * .1f, w * .84f, h * .66f), 10 * d, 10 * d, p);
        p.setColor(0xFF000000);
        c.drawRoundRect(new RectF(w * .2f, h * .16f, w * .78f, h * .6f), 6 * d, 6 * d, p);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(13 * d);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("[....]", w * .49f, h * .42f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        Path l = new Path();
        l.moveTo(w * .06f, h * .98f);
        l.cubicTo(w * .06f, h * .6f, w * .14f, h * .55f, w * .3f, h * .62f);
        l.cubicTo(w * .22f, h * .8f, w * .3f, h * .9f, w * .22f, h * .98f);
        c.drawPath(l, p);
        Path r = new Path();
        r.moveTo(w * .96f, h * .98f);
        r.cubicTo(w * .96f, h * .6f, w * .88f, h * .55f, w * .72f, h * .62f);
        r.cubicTo(w * .8f, h * .8f, w * .72f, h * .9f, w * .8f, h * .98f);
        c.drawPath(r, p);
    }
}
