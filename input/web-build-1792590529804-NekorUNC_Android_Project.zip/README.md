# Nekor UNC Lab — Android project

A mobile Lua editor and UNC-style compatibility checklist packaged as an Android WebView app.

## Included
- Responsive dark UI for phones
- Lua text editor
- Import `.lua` / `.txt` files
- Export `.lua` files
- Local script saving via browser storage
- Manually tracked compatibility checklist
- Local diagnostic console
- No remote CDN dependency

## Build an APK
1. Install Android Studio and a compatible JDK (JDK 17 recommended).
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/`.

The project uses Android Gradle Plugin 8.7.3 and compile SDK 35; install the corresponding Android SDK platform/build tools in Android Studio if prompted.

## Scope
This is an editor and manual compatibility checklist, not a Roblox executor. It does not inject scripts into Roblox, implement anti-cheat evasion, or claim 100% UNC support. Checklist items are untested until you implement and validate them in a permitted runtime.
