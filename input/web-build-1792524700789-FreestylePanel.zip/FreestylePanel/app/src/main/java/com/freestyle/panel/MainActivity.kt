
package com.freestyle.panel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 15, 15)
    private val accent = Color.rgb(125, 145, 205)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "FREESTYLE • PANEL"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "COMPANION SETTINGS"
            textSize = 12f
            setTextColor(accent)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle)

        listOf("MAIN", "CONFIGS", "I.A", "OPTIMIZAR").forEach { label ->
            root.addView(makeButton(label) {
                subtitle.text = "$label SELECTED"
            })
        }

        val heading = TextView(this).apply {
            text = "HH POINT"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 18, 0, 8)
        }
        root.addView(heading)

        listOf("HEAD", "NECK", "FULL BODY").forEach { label ->
            root.addView(makeButton(label) {
                subtitle.text = "$label SELECTED"
            })
        }

        val note = TextView(this).apply {
            text = "Visual demo only • no game modification"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        root.addView(note)

        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48, 48, 48))
            setOnClickListener { action() }
        }
    }
}
