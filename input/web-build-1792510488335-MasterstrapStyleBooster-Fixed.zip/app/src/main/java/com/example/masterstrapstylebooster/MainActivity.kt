package com.example.masterstrapstylebooster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val page = Color.rgb(242, 246, 249)
    private val cardColor = Color.WHITE
    private val ink = Color.rgb(35, 43, 53)
    private val sub = Color.rgb(116, 126, 137)
    private val blue = Color.rgb(48, 181, 220)
    private lateinit var content: LinearLayout
    private lateinit var tabLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = page
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildShell("FastFlags")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun bg(color: Int, radius: Int = 14, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun button(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; setTextColor(blue); gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = bg(Color.WHITE, 12, Color.rgb(225, 231, 236))
        setOnClickListener { action() }
    }

    private fun buildShell(tab: String) {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(page) }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(16))
        }
        scroll.addView(content)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8)); setBackgroundColor(Color.WHITE)
        }
        header.addView(TextView(this).apply {
            text = "◈"; textSize = 25f; setTextColor(Color.rgb(86, 105, 112))
        })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        titles.addView(label("Masterstrap", 18f, ink, true))
        titles.addView(label("FastFlag & Game Boost", 10f, sub))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⚙") { showSettings() })
        outer.addView(header)
        tabLabel = label(tab, 11f, sub, true)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(6), dp(4), dp(6)); setBackgroundColor(Color.WHITE)
        }
        listOf("FastFlags", "FF Settings", "🚀", "Game Mode", "Preset").forEachIndexed { i, name ->
            val actual = if (i == 2) "Boost" else name
            val t = TextView(this).apply {
                text = (if (i == 0) "⚑\\n" else if (i == 1) "⚙\\n" else if (i == 2) "◉\\n" else if (i == 3) "🎮\\n" else "◆\\n") + actual
                textSize = 10f; gravity = Gravity.CENTER
                setTextColor(if ((tab == "FastFlags" && i == 0) || (tab == "FF Settings" && i == 1) || (tab == "Game Mode" && i == 3) || (tab == "Preset" && i == 4)) blue else sub)
                setPadding(dp(2), dp(4), dp(2), dp(4))
                setOnClickListener { buildShell(if (i == 1) "FF Settings" else if (i == 3) "Game Mode" else if (i == 4) "Preset" else "FastFlags") }
            }
            nav.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        outer.addView(nav)
        setContentView(outer)
        if (tab == "FastFlags") fillFastFlags() else fillOther(tab)
    }

    private fun card(parent: LinearLayout, title: String, desc: String? = null, body: (LinearLayout) -> Unit = {}) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(cardColor, 14)
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        box.addView(label(title, 14f, ink, true))
        if (desc != null) box.addView(label(desc, 10f, sub).apply { setPadding(0, dp(4), 0, dp(9)) })
        body(box)
        parent.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun settingRow(parent: LinearLayout, title: String, desc: String, initial: Boolean = false) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        textCol.addView(label(title, 12f, ink, true))
        textCol.addView(label(desc, 10f, sub).apply { setPadding(0, dp(3), dp(6), 0) })
        row.addView(textCol)
        val sw = Switch(this).apply {
            isChecked = initial
            buttonTintList = android.content.res.ColorStateList.valueOf(blue)
            setOnCheckedChangeListener { _, checked ->
                Toast.makeText(this@MainActivity,
                    if (checked) "Preference enabled locally; not applied to Roblox." else "Preference disabled locally.",
                    Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(sw)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(7) })
    }

    private fun dropdown(parent: LinearLayout, title: String, items: List<String>) {
        parent.addView(label(title, 12f, ink, true).apply { setPadding(0, dp(5), 0, dp(5)) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        parent.addView(sp, LinearLayout.LayoutParams(-1, dp(38)))
    }

    private fun fillFastFlags() {
        content.removeAllViews()
        content.addView(button("⚑   FastFlag Editor                         ➜") {
            Toast.makeText(this, "This demo provides UI only; it does not edit Roblox files.", Toast.LENGTH_LONG).show()
        }.apply { gravity = Gravity.CENTER_VERTICAL })
        card(content, "Apply Roblox optimizations",
            "Applies selected optimizations whenever you save and launch. This demo stores preferences only; it cannot apply Roblox FastFlags.") {
            settingRow(it, "Enable optimization preferences", "Turn off to leave settings at their normal configuration.", true)
        }
        card(content, "Graphics quality") {
            dropdown(it, "Anti-aliasing quality (MSAA)", listOf("Automatic", "Off", "2x", "4x", "8x"))
            dropdown(it, "FRM quality override", listOf("Automatic", "1", "5", "10", "15", "21"))
            dropdown(it, "Rendering mode", listOf("Automatic", "Vulkan", "OpenGL"))
            dropdown(it, "Dynamic render resolution", listOf("Automatic", "Enabled", "Disabled"))
        }
        card(content, "Verified Roblox preferences") {
            settingRow(it, "Force lowest Roblox graphics", "Requests low graphics when supported. Not applied by this demo.")
            settingRow(it, "Reduce in-game motion", "Requires supported Roblox settings; not applied by this demo.")
            settingRow(it, "In-game haptics", "Preference toggle only; not connected to Roblox.")
        }
        card(content, "Mobile performance") {
            dropdown(it, "Target frame rate (Global)", listOf("30", "40", "60", "90", "120"))
            settingRow(it, "One-tap graphics boost", "UI preference; actual effects depend on game/device.")
            settingRow(it, "Reduce 3D model detail", "Preference only; no game files are changed.")
            settingRow(it, "Reduce texture load", "Preference only; no game files are changed.")
            settingRow(it, "Optimize 3D model memory", "Preference only; no game files are changed.", true)
        }
        card(content, "Launch Roblox", "Open the official Roblox app.") {
            it.addView(button("▶  Launch Roblox") { launchRoblox() })
        }
        content.addView(label("UI demo • No root • Does not patch Roblox • FPS gains not guaranteed", 10f, sub).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(8))
        })
    }

    private fun fillOther(tab: String) {
        content.removeAllViews()
        when (tab) {
            "FF Settings" -> {
                card(content, "FastFlag Settings", "Demo settings page") {
                    settingRow(it, "Show advanced options", "Local UI preference")
                    settingRow(it, "Confirm before changes", "Recommended", true)
                }
                card(content, "About FastFlags", "Roblox support for client flags varies. This app does not write Roblox configuration.")
            }
            "Game Mode" -> {
                card(content, "Game Mode", "Use Android's own game tools when available.") {
                    it.addView(button("Open display settings") { openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS)) })
                    it.addView(button("Open battery settings") { openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) })
                }
            }
            "Preset" -> {
                card(content, "Presets", "Choose a UI preset. These choices do not change Roblox settings.") {
                    listOf("Balanced", "Performance", "Visual quality").forEach { preset ->
                        it.addView(button(preset) { Toast.makeText(this@MainActivity, "$preset selected (demo only)", Toast.LENGTH_SHORT).show() })
                    }
                }
            }
            else -> {
                card(content, "Masterstrap-style booster", "A similar layout recreated for this Android demo.") {
                    it.addView(button("Launch Roblox") { launchRoblox() })
                }
            }
        }
    }

    private fun launchRoblox() {
        val i = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (i != null) startActivity(i)
        else {
            Toast.makeText(this, "Install Roblox from Google Play first.", Toast.LENGTH_LONG).show()
            openSettings(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.roblox.client")))
        }
    }

    private fun showSettings() {
        Toast.makeText(this, "Settings: Masterstrap-style UI demo", Toast.LENGTH_SHORT).show()
    }
    private fun openSettings(i: Intent) {
        try { startActivity(i) } catch (_: Exception) {
            Toast.makeText(this, "Setting unavailable on this device.", Toast.LENGTH_SHORT).show()
        }
    }
}
