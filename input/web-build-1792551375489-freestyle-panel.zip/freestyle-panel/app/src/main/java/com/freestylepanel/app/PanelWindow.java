package com.freestylepanel.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** The floating window: header (drag / minimize / close), tabs (Main, Configs, I.A, Optimizar) and their pages. */
class PanelWindow extends LinearLayout {
    interface Host {
        void minimize();
        void exit();
        void move(float dx, float dy);
    }

    static final int BG = 0xFF000000, FG = 0xFFFFFFFF, MUTE = 0xFF8E8E8E, EDGE = 0xFF2E2E2E;
    private final Host host;
    private final float density;
    private final FrameLayout content;
    private final LinearLayout[] tabs = new LinearLayout[4];
    private final TextView[] tabText = new TextView[4];
    private final GlyphView[] tabIcon = new GlyphView[4];
    private int current = -1;
    private int target;

    PanelWindow(Context c, Host host) {
        super(c);
        this.host = host;
        density = c.getResources().getDisplayMetrics().density;
        target = c.getSharedPreferences("fp", Context.MODE_PRIVATE).getInt("hhpoint", 0);
        setOrientation(VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(BG);
        bg.setCornerRadius(dp(20));
        setBackground(bg);
        setClipToOutline(true);

        addView(header(), new LayoutParams(-1, dp(46)));

        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        String[] names = {"Main", "Configs", "I.A", "Optimizar"};
        int[] icons = {-1, GlyphView.GEAR, GlyphView.SPARKLE, GlyphView.BOLT};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout t = new LinearLayout(c);
            t.setGravity(Gravity.CENTER);
            if (icons[i] >= 0) {
                GlyphView g = new GlyphView(c, icons[i], FG);
                t.addView(g, new LayoutParams(dp(18), dp(18)));
                tabIcon[i] = g;
            }
            TextView tx = text(names[i], 14, FG);
            tx.setPadding(dp(icons[i] >= 0 ? 8 : 0), 0, 0, 0);
            t.addView(tx);
            tabText[i] = tx;
            tabs[i] = t;
            t.setOnClickListener(v -> showTab(idx));
            row.addView(t, new LayoutParams(0, dp(38), 1f));
        }
        addView(row, new LayoutParams(-1, -2));
        View line = new View(c);
        line.setBackgroundColor(EDGE);
        addView(line, new LayoutParams(-1, dp(2)));
        content = new FrameLayout(c);
        addView(content, new LayoutParams(-1, 0, 1f));
        showTab(0);
    }

    private int dp(int v) { return (int) (v * density + .5f); }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private GradientDrawable shape(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    // ------------------------------------------------------------ header
    private View header() {
        final Context c = getContext();
        FrameLayout h = new FrameLayout(c);
        h.setBackgroundColor(FG);
        TextView title = text("FREESTYLE PANEL", 16, 0xFF111111);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        h.addView(title, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.START));
        ((FrameLayout.LayoutParams) title.getLayoutParams()).leftMargin = dp(16);
        h.addView(new BannerView(c), new FrameLayout.LayoutParams(dp(120), -1, Gravity.CENTER));

        LinearLayout right = new LinearLayout(c);
        right.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout min = iconButton(GlyphView.MINIMIZE, v -> host.minimize());
        FrameLayout close = iconButton(GlyphView.CLOSE, v -> host.exit());
        right.addView(min, new LayoutParams(dp(40), dp(40)));
        right.addView(close, new LayoutParams(dp(40), dp(40)));
        h.addView(right, new FrameLayout.LayoutParams(-2, -1, Gravity.END));
        ((FrameLayout.LayoutParams) right.getLayoutParams()).rightMargin = dp(6);

        // drag the window by the header
        h.setOnTouchListener(new OnTouchListener() {
            float lx, ly;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: lx = e.getRawX(); ly = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        host.move(e.getRawX() - lx, e.getRawY() - ly);
                        lx = e.getRawX(); ly = e.getRawY();
                        return true;
                    default: return true;
                }
            }
        });
        return h;
    }

    private FrameLayout iconButton(int glyph, OnClickListener l) {
        FrameLayout f = new FrameLayout(getContext());
        f.addView(new GlyphView(getContext(), glyph, 0xFF111111), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setOnClickListener(l);
        return f;
    }

    // ------------------------------------------------------------ tabs
    private void showTab(int i) {
        if (i == current) return;
        current = i;
        for (int k = 0; k < 4; k++) {
            boolean sel = k == i;
            tabs[k].setBackground(sel ? shape(FG, 6, 0, 0) : null);
            tabText[k].setTextColor(sel ? BG : FG);
            if (tabIcon[k] != null) tabIcon[k].setColor(sel ? BG : FG);
        }
        content.removeAllViews();
        View page = i == 0 ? mainPage() : i == 1 ? new SensitivityPanel(getContext(), false) : i == 2 ? aiPage() : optimizePage();
        page.setAlpha(0f);
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
        page.animate().alpha(1f).setDuration(160).start();
    }

    private View mainPage() {
        final Context c = getContext();
        LinearLayout root = new LinearLayout(c);
        LinearLayout left = new LinearLayout(c);
        left.setOrientation(VERTICAL);
        left.setPadding(dp(10), dp(8), dp(6), dp(6));
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(new GlyphView(c, GlyphView.HEX_AIM, FG), new LayoutParams(dp(34), dp(30)));
        TextView t = text("HH POINT", 18, FG);
        t.setPadding(dp(12), 0, 0, 0);
        head.addView(t);
        left.addView(head, new LayoutParams(-1, dp(40)));
        String[] names = {"HEAD", "NECK", "FULL BODY"};
        final TextView[] btns = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView b = text(names[i], 17, FG);
            b.setLetterSpacing(0.18f);
            b.setGravity(Gravity.CENTER);
            btns[i] = b;
            b.setOnClickListener(v -> {
                target = idx;
                c.getSharedPreferences("fp", Context.MODE_PRIVATE).edit().putInt("hhpoint", idx).apply();
                paint(btns);
            });
            LayoutParams lp = new LayoutParams(-1, dp(48));
            lp.topMargin = dp(8);
            left.addView(b, lp);
        }
        paint(btns);
        TextView note = text("Saved selection only. This app does not aim or control any game.", 10, MUTE);
        note.setPadding(dp(4), dp(8), dp(4), 0);
        left.addView(note);
        root.addView(left, new LayoutParams(0, -1, 1f));
        root.addView(new SilhouetteView(c), new LayoutParams(0, -1, 1f));
        return root;
    }

    private void paint(TextView[] btns) {
        for (int i = 0; i < btns.length; i++) {
            boolean sel = i == target;
            btns[i].setBackground(shape(BG, 26, sel ? FG : 0xFF333333, sel ? 2 : 3));
        }
    }

    private View aiPage() {
        LinearLayout l = new LinearLayout(getContext());
        l.setOrientation(VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(24), dp(16), dp(24), dp(16));
        l.addView(new GlyphView(getContext(), GlyphView.SPARKLE, MUTE), new LayoutParams(dp(30), dp(30)));
        TextView t = text("I.A is not available in this build.", 15, FG);
        t.setPadding(0, dp(12), 0, dp(4));
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        TextView s = text("This app only shows reference values and does not control any game.", 12, MUTE);
        s.setGravity(Gravity.CENTER);
        l.addView(s);
        return l;
    }

    private View optimizePage() {
        final Context c = getContext();
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(VERTICAL);
        l.setPadding(dp(18), dp(14), dp(18), dp(12));
        final TextView ram = text("", 14, FG);
        final BarHolder bar = new BarHolder(c);
        l.addView(text("Memory", 17, FG));
        ram.setPadding(0, dp(8), 0, dp(6));
        l.addView(ram);
        l.addView(bar.frame, new LayoutParams(-1, dp(16)));
        updateRam(ram, bar);
        LinearLayout btns = new LinearLayout(c);
        btns.setPadding(0, dp(16), 0, 0);
        TextView free = pill("FREE MEMORY");
        free.setOnClickListener(v -> {
            System.gc();
            updateRam(ram, bar);
            Toast.makeText(c, "Memory refreshed", Toast.LENGTH_SHORT).show();
        });
        TextView batt = pill("BATTERY");
        batt.setOnClickListener(v -> {
            try {
                c.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {}
        });
        LayoutParams a = new LayoutParams(0, dp(44), 1f);
        a.rightMargin = dp(6);
        LayoutParams b2 = new LayoutParams(0, dp(44), 1f);
        b2.leftMargin = dp(6);
        btns.addView(free, a);
        btns.addView(batt, b2);
        l.addView(btns);
        TextView n = text("Android manages other apps' memory itself; this only refreshes the readout and frees what this panel holds.", 10, MUTE);
        n.setPadding(0, dp(10), 0, 0);
        l.addView(n);
        return l;
    }

    private TextView pill(String s) {
        TextView b = text(s, 13, FG);
        b.setLetterSpacing(0.14f);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(BG, 22, 0xFF333333, 3));
        return b;
    }

    /** Draws a simple used-memory bar. */
    private static class BarHolder {
        final FrameLayout frame;
        BarHolder(Context c) { frame = new FrameLayout(c); }
    }

    private void updateRam(TextView ram, BarHolder bar) {
        Context c = getContext();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long totalMb = mi.totalMem / (1024 * 1024), freeMb = mi.availMem / (1024 * 1024);
        ram.setText("Free RAM: " + freeMb + " MB of " + totalMb + " MB");
        bar.frame.removeAllViews();
        int used = totalMb == 0 ? 0 : (int) (100 - freeMb * 100 / totalMb);
        bar.frame.addView(new BarView(c, used), new FrameLayout.LayoutParams(-1, -1));
    }
}
