package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

/** White hexagon badge with a dark glyph (or short text) inside. */
class HexIcon extends FrameLayout {
    HexIcon(Context c, int glyph) {
        super(c);
        addView(new GlyphView(c, GlyphView.HEX, 0xFFFFFFFF), new LayoutParams(-1, -1));
        addView(new GlyphView(c, glyph, 0xFF000000), new LayoutParams(-1, -1));
    }

    HexIcon(Context c, String text) {
        super(c);
        addView(new GlyphView(c, GlyphView.HEX, 0xFFFFFFFF), new LayoutParams(-1, -1));
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(0xFF000000);
        t.setTextSize(8);
        t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setLineSpacing(0, .85f);
        addView(t, new LayoutParams(-1, -1));
    }
}
