package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Read-only horizontal value bar (0-100). */
class BarView extends View {
    private final int value;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    BarView(Context c, int value) { super(c); this.value = Math.max(0, Math.min(100, value)); }

    @Override protected void onDraw(Canvas c) {
        float h = getHeight(), w = getWidth(), t = Math.min(h, getResources().getDisplayMetrics().density * 4f);
        float top = (h - t) / 2f;
        p.setColor(0xFF3A3A3A);
        c.drawRoundRect(new RectF(0, top, w, top + t), t / 2, t / 2, p);
        p.setColor(0xFFFFFFFF);
        c.drawRoundRect(new RectF(0, top, w * value / 100f, top + t), t / 2, t / 2, p);
    }
}
