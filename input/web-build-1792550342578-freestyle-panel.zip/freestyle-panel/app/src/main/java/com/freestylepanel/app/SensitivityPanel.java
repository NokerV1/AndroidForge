package com.freestylepanel.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** The sensitivity UI (chooser -> DPI lists -> detail). Used inside the app and inside the floating window. */
class SensitivityPanel extends FrameLayout {
    static final int BG = 0xFF000000, FG = 0xFFFFFFFF, MUTE = 0xFF8E8E8E;

    // Sensitivity data per DPI tab (No DPI, -600, +600, +1000) x 5 sets x {General, Red Dot, 2x, 4x, AWM}.
    // Values read from the recording are exact; AWM and the sets that never appeared fully on screen are placeholders.
    static final String[] TABS = {"No DPI", "- 600", "+ 600", "+ 1000"};
    static final int[][][] DATA = {
            {{87, 93, 96, 93, 82}, {89, 90, 93, 99, 24}, {86, 92, 94, 94, 31}, {81, 91, 92, 96, 28}, {99, 96, 95, 95, 35}},
            {{76, 94, 91, 98, 25}, {72, 90, 91, 93, 22}, {82, 97, 96, 95, 30}, {84, 93, 92, 96, 27}, {88, 95, 94, 97, 33}},
            {{79, 94, 96, 94, 26}, {70, 95, 98, 98, 23}, {76, 91, 95, 97, 29}, {81, 92, 93, 96, 27}, {85, 94, 95, 98, 31}},
            {{81, 92, 98, 100, 28}, {75, 93, 92, 99, 24}, {73, 100, 93, 97, 21}, {78, 94, 95, 98, 26}, {83, 96, 97, 99, 30}}};
    static final String[] LABELS = {"General", "Red Dot", "2x Scope", "4x Scope", "AWM Scope"};
    static final int[] ICONS = {GlyphView.AIM, GlyphView.AIM_RED, GlyphView.AIM_2X, GlyphView.AIM_4X, GlyphView.AIM_AWM};
    static final float[] FADE = {1f, .8f, .6f, .42f, .26f};

    private final SharedPreferences sp;
    private final float density;
    private final boolean withBanner;
    private View current;
    private int stage = 0, mode = 100, dpiTab = 0, detailSet = 0;

    SensitivityPanel(Context c, boolean withBanner) {
        super(c);
        this.withBanner = withBanner;
        sp = c.getSharedPreferences("fp", Context.MODE_PRIVATE);
        density = c.getResources().getDisplayMetrics().density;
        setBackgroundColor(BG);
        render();
    }

    /** Steps back one level. Returns false when already at the first screen. */
    boolean back() {
        if (stage == 0) return false;
        stage--;
        render();
        return true;
    }

    // ------------------------------------------------------------ helpers
    private int dp(int v) { return (int) (v * density + .5f); }

    private GradientDrawable shape(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout vl() {
        LinearLayout l = new LinearLayout(getContext());
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new OvershootInterpolator(2.5f)).start();
            return false;
        });
    }

    private void render() {
        View page = stage == 0 ? chooserPage() : stage == 1 ? listPage() : detailPage();
        final View old = current;
        current = page;
        page.setAlpha(0f);
        page.setTranslationY(dp(10));
        addView(page, new FrameLayout.LayoutParams(-1, -1));
        page.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        if (old != null) old.animate().alpha(0f).setDuration(100).withEndAction(() -> removeView(old)).start();
    }

    private void banner(LinearLayout col) {
        if (!withBanner) return;
        col.addView(new BannerView(getContext()), new LinearLayout.LayoutParams(-1, dp(104)));
    }

    // ------------------------------------------------------------ pages
    private View chooserPage() {
        LinearLayout col = vl();
        banner(col);
        LinearLayout mid = vl();
        mid.setGravity(Gravity.CENTER);
        mid.setPadding(dp(28), dp(8), dp(28), dp(24));
        mid.addView(new GlyphView(getContext(), GlyphView.SLIDERS, FG), new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = tv("Choose the maximum sensitivity for freestyle.", 15, FG);
        t.setLetterSpacing(0.08f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(16), 0, dp(22));
        mid.addView(t);
        mid.addView(pillButton("FREESTYLE SENSITIVITY 100X", 100));
        mid.addView(pillButton("FREESTYLE SENSITIVITY 200X", 200));
        col.addView(mid, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    private View pillButton(String label, final int m) {
        LinearLayout b = new LinearLayout(getContext());
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(FG, 30, 0, 0));
        TextView t = tv(label, 11.5f, BG);
        t.setLetterSpacing(0.12f);
        b.addView(t);
        TextView a = tv("  →", 15, BG);
        a.setTypeface(null, Typeface.BOLD);
        b.addView(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> { mode = m; stage = 1; render(); });
        press(b);
        return b;
    }

    private View listPage() {
        LinearLayout col = vl();
        banner(col);
        LinearLayout chips = new LinearLayout(getContext());
        chips.setGravity(Gravity.CENTER_VERTICAL);
        chips.setPadding(dp(8), dp(10), dp(8), dp(10));
        final ScrollView sv = new ScrollView(getContext());
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        final LinearLayout cards = vl();
        cards.setPadding(dp(14), dp(4), dp(14), dp(16));
        sv.addView(cards);
        final TextView[] chipViews = new TextView[4];
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView c = tv(TABS[i], 14, FG);
            c.setGravity(Gravity.CENTER);
            chips.addView(c, new LinearLayout.LayoutParams(0, dp(40), 1f));
            chipViews[i] = c;
            c.setOnClickListener(v -> {
                dpiTab = idx;
                paintChips(chipViews);
                fillCards(cards);
                sv.scrollTo(0, 0);
            });
            press(c);
        }
        paintChips(chipViews);
        fillCards(cards);
        col.addView(chips, new LinearLayout.LayoutParams(-1, -2));
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    private void paintChips(TextView[] cs) {
        for (int i = 0; i < cs.length; i++) {
            boolean sel = i == dpiTab;
            cs[i].setBackground(sel ? shape(FG, 20, 0, 0) : null);
            cs[i].setTextColor(sel ? BG : FG);
        }
    }

    private void fillCards(LinearLayout cards) {
        cards.removeAllViews();
        for (int s = 0; s < DATA[dpiTab].length; s++) cards.addView(card(s));
        cards.setAlpha(0f);
        cards.animate().alpha(1f).setDuration(180).start();
    }

    private View card(final int set) {
        FrameLayout f = new FrameLayout(getContext());
        f.setBackground(shape(0, 20, FG, 1));
        LinearLayout rows = vl();
        rows.setPadding(dp(14), dp(12), dp(14), dp(16));
        int[] vals = DATA[dpiTab][set];
        for (int i = 0; i < 5; i++) {
            LinearLayout r = new LinearLayout(getContext());
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setAlpha(FADE[i]);
            FrameLayout ib = new FrameLayout(getContext());
            ib.setBackground(shape(FG, 5, 0, 0));
            ib.addView(new GlyphView(getContext(), ICONS[i], BG), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
            r.addView(ib, new LinearLayout.LayoutParams(dp(20), dp(20)));
            TextView l = tv(LABELS[i] + ":", 12.5f, FG);
            l.setPadding(dp(8), 0, 0, 0);
            r.addView(l, new LinearLayout.LayoutParams(dp(84), -2));
            r.addView(new BarView(getContext(), vals[i]), new LinearLayout.LayoutParams(0, dp(16), 1f));
            TextView val = tv(String.valueOf(vals[i]), 12.5f, FG);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(dp(34), -2));
            rows.addView(r, new LinearLayout.LayoutParams(-1, dp(32)));
        }
        f.addView(rows, new FrameLayout.LayoutParams(-1, -2));
        TextView tag = tv("Sensitivity " + (set + 1), 13, BG);
        tag.setPadding(dp(16), dp(9), dp(16), dp(9));
        float r = dp(20);
        GradientDrawable tb = new GradientDrawable();
        tb.setColor(FG);
        tb.setCornerRadii(new float[]{r, r, 0, 0, r, r, 0, 0});
        tag.setBackground(tb);
        f.addView(tag, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        lp.bottomMargin = dp(6);
        f.setLayoutParams(lp);
        f.setOnClickListener(v2 -> { detailSet = set; stage = 2; render(); });
        press(f);
        return f;
    }

    private View detailPage() {
        ScrollView sv = new ScrollView(getContext());
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = vl();
        col.setPadding(dp(18), dp(20), dp(18), dp(24));
        LinearLayout head = new LinearLayout(getContext());
        head.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout backBtn = new FrameLayout(getContext());
        backBtn.setBackground(shape(FG, 10, 0, 0));
        backBtn.addView(new GlyphView(getContext(), GlyphView.SLIDERS, BG), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        backBtn.setOnClickListener(v -> { stage = 1; render(); });
        press(backBtn);
        head.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        head.addView(new View(getContext()), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView pill = tv(TABS[dpiTab], 13, BG);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(18), dp(8), dp(18), dp(8));
        pill.setBackground(shape(FG, 20, 0, 0));
        head.addView(pill);
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = tv("Sensitivity " + (detailSet + 1) + "  ·  " + mode + "X", 13, MUTE);
        sub.setPadding(0, dp(22), 0, dp(8));
        col.addView(sub);
        int[] vals = DATA[dpiTab][detailSet];
        for (int i = 0; i < 5; i++) {
            LinearLayout r = new LinearLayout(getContext());
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(new GlyphView(getContext(), ICONS[i], FG), new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView l = tv(LABELS[i], 14, FG);
            l.setPadding(dp(10), 0, 0, 0);
            r.addView(l, new LinearLayout.LayoutParams(dp(92), -2));
            r.addView(new BarView(getContext(), vals[i]), new LinearLayout.LayoutParams(0, dp(20), 1f));
            TextView val = tv(String.valueOf(vals[i]), 13, FG);
            val.setGravity(Gravity.END);
            r.addView(val, new LinearLayout.LayoutParams(dp(34), -2));
            col.addView(r, new LinearLayout.LayoutParams(-1, dp(40)));
        }
        LinearLayout fire = new LinearLayout(getContext());
        fire.setGravity(Gravity.CENTER_VERTICAL);
        fire.addView(new GlyphView(getContext(), GlyphView.FIRE, FG), new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView fl = tv("Fire button", 14, FG);
        fl.setPadding(dp(10), 0, 0, 0);
        fire.addView(fl, new LinearLayout.LayoutParams(0, -2, 1f));
        fire.addView(tv(String.valueOf(41 + detailSet * 2 - dpiTab), 13, 0xFFBBBBBB));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(40));
        fp.topMargin = dp(26);
        col.addView(fire, fp);

        TextView cp = tv("Cursor/Pointer Speed", 14, FG);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, dp(34), 0, dp(6));
        col.addView(cp);
        SeekBar speed = new SeekBar(getContext());
        speed.setMax(100);
        speed.setProgress(sp.getInt("pointer", 100));
        speed.setProgressTintList(ColorStateList.valueOf(FG));
        speed.setThumbTintList(ColorStateList.valueOf(FG));
        speed.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF4A4A4A));
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) sp.edit().putInt("pointer", p).apply(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        col.addView(speed, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout lab = new LinearLayout(getContext());
        String[] ls = {"Minimum", "Average", "Maximum"};
        for (int i = 0; i < 3; i++) {
            TextView t = tv(ls[i], 13, FG);
            t.setGravity(i == 0 ? Gravity.START : i == 2 ? Gravity.END : Gravity.CENTER);
            lab.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        col.addView(lab);
        sv.addView(col);
        return sv;
    }
}
