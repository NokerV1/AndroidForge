package com.freestylepanel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Original decorative art: a landscape phone held in two hands (drawn in code). */
class GripView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    GripView(Context c) { super(c); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
        float cx = w / 2f, cy = h * 0.42f;
        c.save();
        c.rotate(-5, cx, cy);
        RectF phone = new RectF(cx - w * 0.36f, cy - h * 0.26f, cx + w * 0.36f, cy + h * 0.26f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFEDEDED);
        c.drawRoundRect(phone, 10 * d, 10 * d, p);
        p.setColor(0xFF000000);
        c.drawRoundRect(new RectF(phone.left + 5 * d, phone.top + 5 * d, phone.right - 5 * d, phone.bottom - 5 * d), 7 * d, 7 * d, p);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(11 * d);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("[....]", cx, cy + 4 * d, p);
        c.restore();
        // hands: simple outlined curves
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFFFFFFFF);
        Path l = new Path();
        l.moveTo(w * 0.04f, h * 0.98f);
        l.cubicTo(w * 0.04f, h * 0.7f, w * 0.12f, h * 0.55f, w * 0.3f, h * 0.62f);
        l.quadTo(w * 0.4f, h * 0.7f, w * 0.3f, h * 0.78f);
        c.drawPath(l, p);
        Path r = new Path();
        r.moveTo(w * 0.96f, h * 0.98f);
        r.cubicTo(w * 0.98f, h * 0.7f, w * 0.88f, h * 0.55f, w * 0.7f, h * 0.62f);
        r.quadTo(w * 0.6f, h * 0.7f, w * 0.7f, h * 0.78f);
        c.drawPath(r, p);
    }
}
