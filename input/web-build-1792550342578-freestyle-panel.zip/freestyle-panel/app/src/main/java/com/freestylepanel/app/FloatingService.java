package com.freestylepanel.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Foreground service that shows the draggable floating icon over other apps. */
public class FloatingService extends Service {
    static final String ACTION_STOP = "com.freestylepanel.app.STOP";
    static final String CHANNEL = "panel";
    static volatile boolean running = false;

    private WindowManager wm;
    private FrameLayout icon;
    private FrameLayout panelWin;
    private WindowManager.LayoutParams lp;
    private SharedPreferences sp;
    private final SharedPreferences.OnSharedPreferenceChangeListener listener = (s, k) -> apply();

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        sp = getSharedPreferences("fp", MODE_PRIVATE);
    }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        if (in != null && ACTION_STOP.equals(in.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Floating icon", NotificationManager.IMPORTANCE_LOW));
        Notification n = notification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        if (icon == null) addIcon();
        sp.registerOnSharedPreferenceChangeListener(listener);
        apply();
        return START_NOT_STICKY;
    }

    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, FloatingService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action act = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_power_fg), "Stop", stop).build();
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_power_fg)
                .setContentTitle("Freestyle Panel is running")
                .setContentText("Floating icon active. Tap to open.")
                .setContentIntent(open)
                .addAction(act)
                .setOngoing(true)
                .build();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private void addIcon() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        icon = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF000000);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(2), 0xFF1DD18B);
        icon.setBackground(bg);
        GlyphView g = new GlyphView(this, GlyphView.POWER, 0xFF1DD18B);
        icon.addView(g, new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        lp = new WindowManager.LayoutParams(dp(54), dp(54),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = sp.getInt("fx", dp(16));
        lp.y = sp.getInt("fy", dp(180));
        icon.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;
            boolean drag;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = lp.x; sy = lp.y; drag = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                        if (!drag && Math.hypot(mx, my) > dp(8)) drag = true;
                        if (drag) {
                            lp.x = sx + (int) mx;
                            lp.y = sy + (int) my;
                            try { wm.updateViewLayout(icon, lp); } catch (Throwable ignored) {}
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (drag) sp.edit().putInt("fx", lp.x).putInt("fy", lp.y).apply();
                        else togglePanel();
                        return true;
                    default:
                        return false;
                }
            }
        });
        try { wm.addView(icon, lp); } catch (Throwable t) { icon = null; stopSelf(); }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("go", "sens");
        try { startActivity(i); } catch (Throwable ignored) {}
    }


    // ------------------------------------------------------------ floating sensitivity panel
    private void togglePanel() {
        if (panelWin != null) closePanel(); else openPanel();
    }

    private void openPanel() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        try {
            DisplayMetrics real = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(real);
            dm = real;
        } catch (Throwable ignored) {}
        int w = Math.min(dm.widthPixels - dp(24), dp(440));
        int h = (int) (dm.heightPixels * 0.78f);
        final FrameLayout frame = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF000000);
        bg.setCornerRadius(dp(24));
        bg.setStroke(dp(1), 0xFFFFFFFF);
        frame.setBackground(bg);
        frame.setClipToOutline(true);
        frame.addView(new SensitivityPanel(this, true), new FrameLayout.LayoutParams(-1, -1));

        FrameLayout close = new FrameLayout(this);
        GradientDrawable cb = new GradientDrawable();
        cb.setShape(GradientDrawable.OVAL);
        cb.setColor(0xFFFFFFFF);
        close.setBackground(cb);
        TextView x = new TextView(this);
        x.setText("\u2715");
        x.setTextColor(0xFF000000);
        x.setTextSize(14);
        x.setGravity(Gravity.CENTER);
        close.addView(x, new FrameLayout.LayoutParams(-1, -1));
        close.setOnClickListener(v -> closePanel());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.TOP | Gravity.END);
        cp.topMargin = dp(10);
        cp.rightMargin = dp(10);
        frame.addView(close, cp);

        WindowManager.LayoutParams plp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        plp.gravity = Gravity.CENTER;
        frame.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_OUTSIDE) { closePanel(); return true; }
            return false;
        });
        try {
            wm.addView(frame, plp);
        } catch (Throwable t) {
            return;
        }
        panelWin = frame;
        frame.setAlpha(0f);
        frame.setScaleX(.94f);
        frame.setScaleY(.94f);
        frame.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start();
    }

    private void closePanel() {
        final FrameLayout f = panelWin;
        if (f == null) return;
        panelWin = null;
        f.animate().alpha(0f).scaleX(.94f).scaleY(.94f).setDuration(140).withEndAction(() -> {
            try { wm.removeView(f); } catch (Throwable ignored) {}
        }).start();
    }

    /** Applies show/hide (hidden also locks it: not touchable) and opacity from preferences. */
    private void apply() {
        if (icon == null || wm == null) return;
        boolean show = sp.getBoolean("iconShow", true);
        int pct = Math.max(10, Math.min(100, sp.getInt("opacity", 100)));
        icon.setAlpha(pct / 100f);
        icon.setVisibility(show ? View.VISIBLE : View.INVISIBLE);
        if (show) lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(icon, lp); } catch (Throwable ignored) {}
    }

    @Override public void onDestroy() {
        running = false;
        try { sp.unregisterOnSharedPreferenceChangeListener(listener); } catch (Throwable ignored) {}
        if (icon != null && wm != null) {
            try { wm.removeView(icon); } catch (Throwable ignored) {}
        }
        if (panelWin != null && wm != null) {
            try { wm.removeView(panelWin); } catch (Throwable ignored) {}
        }
        panelWin = null;
        icon = null;
        super.onDestroy();
    }
}
