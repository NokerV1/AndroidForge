# Freestyle Panel Android project

This Android project displays `freestyle_panel.html` inside a WebView. The HTML has been styled to resemble the supplied compact floating-panel reference: white title bar, dark tab row, HH POINT controls, and a character preview.

## Build requirements
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 with a compatible Gradle 8.x version

## Build
From the project root, run:

```bash
gradle assembleDebug
```

The APK output path is `app/build/outputs/apk/debug/app-debug.apk`.

This ZIP does not bundle a Gradle wrapper JAR. Your build environment must provide Gradle and the Android SDK.
