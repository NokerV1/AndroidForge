package com.masterstrap.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** Foreground service: owns the launch boosts and keeps Masterstrap alive while Roblox runs. */
public class BoostService extends Service {
    static final String ACTION_STOP = "com.masterstrap.app.STOP";
    static final String CHANNEL = "session";
    static final int NOTE_ID = 1;
    static final long BOOST_MS = 60_000L, MAX_SESSION_MS = 3L * 60 * 60 * 1000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;
    private boolean bg;
    private volatile boolean fpsRun;
    private TextView fpsView;
    private WindowManager wm;
    private final Runnable endBoosts = () -> {
        releaseLocks();
        if (bg) notify(note("Running in the background", "Boosts finished. Tap to open, or Stop to end."));
        else stopSelf();
    };
    private final Runnable endAll = this::stopSelf;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        if (in != null && ACTION_STOP.equals(in.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Roblox session", NotificationManager.IMPORTANCE_LOW));
        Notification n = note("Boosting your Roblox launch", "Masterstrap is running in the background.");
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTE_ID, n);

        h.removeCallbacks(endBoosts);
        h.removeCallbacks(endAll);
        releaseLocks();
        boolean wantFps = in != null && in.getBooleanExtra("fps", false);
        bg = in == null || in.getBooleanExtra("bg", true) || wantFps;
        if (wantFps && Settings.canDrawOverlays(this)) startFps(in.getStringExtra("pkg")); else stopFps();
        boolean hot = in != null && in.getBooleanExtra("hot", false);
        if (!hot) {
            if (in == null || in.getBooleanExtra("cpuawake", true)) {
                try {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "masterstrap:session");
                    wake.acquire(BOOST_MS + 5000);
                } catch (Throwable ignored) {}
            }
            if (in == null || in.getBooleanExtra("lowwifi", true)) {
                try {
                    WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                    wifi = wm.createWifiLock(mode, "masterstrap:wifi");
                    wifi.acquire();
                } catch (Throwable ignored) {}
            }
        }
        h.postDelayed(endBoosts, BOOST_MS);
        if (bg) h.postDelayed(endAll, MAX_SESSION_MS);
        return START_NOT_STICKY;
    }

    private Notification note(String title, String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, BoostService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action act = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_rocket_fg), "Stop", stopPi).build();
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_rocket_fg)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .addAction(act)
                .setOngoing(true)
                .build();
    }

    private void notify(Notification n) {
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTE_ID, n);
    }

    private void releaseLocks() {
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Throwable ignored) {}
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Throwable ignored) {}
        wake = null;
        wifi = null;
    }

    @Override public void onDestroy() {
        stopFps();
        h.removeCallbacksAndMessages(null);
        releaseLocks();
        super.onDestroy();
    }

    // ------------------------------------------------------------ floating FPS counter (needs root to read frame timing)
    private void startFps(final String pkg) {
        if (fpsView != null || pkg == null) return;
        float d = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        fpsView = new TextView(this);
        fpsView.setText("FPS: --");
        fpsView.setTextColor(0xFFFFFFFF);
        fpsView.setTextSize(11);
        fpsView.setTypeface(Typeface.MONOSPACE);
        fpsView.setPadding((int) (8 * d), (int) (3 * d), (int) (8 * d), (int) (3 * d));
        fpsView.setBackgroundColor(0x99777777);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0;
        lp.y = (int) (24 * d);
        try { wm.addView(fpsView, lp); } catch (Throwable t) { fpsView = null; return; }
        fpsRun = true;
        new Thread(() -> fpsLoop(pkg), "masterstrap-fps").start();
    }

    private void stopFps() {
        fpsRun = false;
        if (fpsView != null && wm != null) {
            try { wm.removeView(fpsView); } catch (Throwable ignored) {}
        }
        fpsView = null;
    }

    private void setFpsText(final String t, final int color) {
        h.post(() -> { if (fpsView != null) { fpsView.setText(t); fpsView.setTextColor(color); } });
    }

    private void fpsLoop(String pkg) {
        if (!Root.available()) {
            setFpsText("FPS: root needed to read Roblox frame rate", 0xFFFFD166);
            return;
        }
        String layer = null;
        while (fpsRun) {
            try {
                if (layer == null) layer = pickLayer(Root.run("dumpsys SurfaceFlinger --list"), pkg);
                if (layer == null) { setFpsText("FPS: waiting for Roblox...", 0xFFFFFFFF); Thread.sleep(1500); continue; }
                String out = Root.run("dumpsys SurfaceFlinger --latency \"" + layer + "\"");
                if (out == null) { layer = null; Thread.sleep(1000); continue; }
                double[] r = parseFps(out);
                setFpsText(String.format(java.util.Locale.US, "FPS: %.1f/s %.1f msec %d%%", r[0], r[1], (int) r[2]), 0xFFFFFFFF);
                Thread.sleep(800);
            } catch (InterruptedException e) {
                return;
            } catch (Throwable t) {
                layer = null;
            }
        }
    }

    private static String pickLayer(String list, String pkg) {
        if (list == null) return null;
        String blast = null, surface = null, any = null;
        for (String line : list.split("\n")) {
            String l = line.trim();
            if (!l.contains(pkg)) continue;
            if (l.contains("SurfaceView") && l.contains("BLAST") && blast == null) blast = l;
            else if (l.contains("SurfaceView") && surface == null) surface = l;
            else if (any == null) any = l;
        }
        return blast != null ? blast : surface != null ? surface : any;
    }

    /**
     * Returns {fps, pacing msec, late %} from the frames presented during the last second.
     * pacing msec = average deviation of frame intervals from the median interval (like a frame-time jitter readout);
     * late % = share of frames that arrived more than 1.5x later than the median interval.
     */
    private static double[] parseFps(String out) {
        String[] ls = out.split("\n");
        long max = 0;
        long[] ts = new long[ls.length];
        int n = 0;
        for (int i = 1; i < ls.length; i++) {
            String[] c = ls[i].trim().split("\\s+");
            if (c.length < 3) continue;
            try {
                long t = Long.parseLong(c[1]);
                if (t > 0 && t < Long.MAX_VALUE / 2) { ts[n++] = t; if (t > max) max = t; }
            } catch (Exception ignored) {}
        }
        if (n < 2 || System.nanoTime() - max > 1_500_000_000L) return new double[]{0, 0, 0};
        java.util.Arrays.sort(ts, 0, n);
        int from = 0;
        while (from < n - 2 && ts[from] <= max - 1_000_000_000L) from++;
        int cnt = n - from;
        if (cnt < 2 || ts[n - 1] == ts[from]) return new double[]{0, 0, 0};
        double fps = (cnt - 1) / ((ts[n - 1] - ts[from]) / 1e9);
        double[] dt = new double[cnt - 1];
        for (int i = 0; i < dt.length; i++) dt[i] = (ts[from + i + 1] - ts[from + i]) / 1e6;
        double[] sorted = dt.clone();
        java.util.Arrays.sort(sorted);
        double median = sorted[sorted.length / 2];
        double dev = 0;
        int late = 0;
        for (double d : dt) {
            dev += Math.abs(d - median);
            if (d > median * 1.5) late++;
        }
        return new double[]{fps, dev / dt.length, Math.round(100.0 * late / dt.length)};
    }
}
