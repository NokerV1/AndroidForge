# Masterstrap (recreated from screen recording)

Pure-Java Android app (no external libraries). minSdk 26, targetSdk 34.

## Build the APK
**GitHub (no install):** create a new repo, upload this folder's contents, open the *Actions* tab,
run "Build APK" and download the `Masterstrap-APK` artifact (debug-signed, installable).

**Android Studio:** open this folder, then Build > Build APK(s).

## Notes
- Screens: FastFlag, FF Settings (+Mods), Game Mode, Preset, FastFlag Editor, Settings & About, launch animation.
- Rocket button saves your toggles, builds a FastFlag JSON, runs Safe Boosts (wake lock, low-latency Wi-Fi, thermal check) and launches Roblox.
- Only a handful of toggles are mapped to real FastFlag names (see `computeFlags()` in MainActivity.java). Edit freely.
- Applying flags needs root: the rocket force-stops Roblox, copies ClientAppSettings.json into its data folder with the right owner, and reports success or the reason it failed (also shown in Settings).
- Pro/crown items are locked and license activation is a stub.
- Smoothness: cached tab pages with fade/slide transitions, sliding nav indicator, press feedback, rocket liftoff animation.
- Background: a foreground service (BoostService) holds the wake/Wi-Fi locks and keeps Masterstrap alive during a Roblox session (max 3h; Stop from the notification or Settings).
- FPS overlay: Display FPS adds a floating counter (needs overlay permission + root; reads SurfaceFlinger frame timing).
