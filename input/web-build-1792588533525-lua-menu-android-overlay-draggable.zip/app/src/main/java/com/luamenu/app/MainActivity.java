package com.luamenu.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int PICK_REQUEST = 1;
    private WebView web;
    private WebView floatingWeb;
    private WindowManager windowManager;
    private WindowManager.LayoutParams floatingParams;
    private TextView floatingHandle;
    private WindowManager.LayoutParams handleParams;
    private ValueCallback<Uri[]> pending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        web = new WebView(this);
        configureWebView(web);
        setContentView(web);
        web.addJavascriptInterface(new OverlayBridge(false), "AndroidOverlay");
        web.setWebChromeClient(makeChromeClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        view.setBackgroundColor(Color.TRANSPARENT);
        view.setWebViewClient(new WebViewClient());
    }

    private WebChromeClient makeChromeClient() {
        return new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pending != null) pending.onReceiveValue(null);
                pending = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Select Lua text file"), PICK_REQUEST);
                } catch (Exception e) {
                    pending = null;
                    return false;
                }
                return true;
            }
        };
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showFloatingMenu() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Appear on top first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (floatingWeb != null) {
            floatingWeb.setVisibility(View.VISIBLE);
            return;
        }

        floatingWeb = new WebView(this);
        configureWebView(floatingWeb);
        floatingWeb.addJavascriptInterface(new OverlayBridge(true), "AndroidOverlay");
        floatingWeb.setWebChromeClient(makeChromeClient());

        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int width = Math.min(dp(300), Math.max(dp(240), screenW - dp(24)));
        int height = Math.min(dp(390), Math.max(dp(260), screenH - dp(100)));
        floatingParams = new WindowManager.LayoutParams(
                width, height,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        floatingParams.gravity = Gravity.TOP | Gravity.LEFT;
        floatingParams.x = Math.max(dp(8), (screenW - width) / 2);
        floatingParams.y = dp(36);
        // Long-press anywhere on the floating panel to drag it without blocking normal taps.
        floatingWeb.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean dragging;
            private final android.os.Handler handler = new android.os.Handler();
            private Runnable startDrag;

            @Override public boolean onTouch(View v, android.view.MotionEvent event) {
                switch (event.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = floatingParams.x; startY = floatingParams.y;
                        dragging = false;
                        startDrag = () -> dragging = true;
                        handler.postDelayed(startDrag, 450);
                        return false;
                    case android.view.MotionEvent.ACTION_MOVE:
                        if (dragging && floatingParams != null) {
                            floatingParams.x = Math.max(0, Math.min(screenW - floatingParams.width,
                                    startX + Math.round(event.getRawX() - downX)));
                            floatingParams.y = Math.max(0, Math.min(screenH - dp(80),
                                    startY + Math.round(event.getRawY() - downY)));
                            try { windowManager.updateViewLayout(floatingWeb, floatingParams); } catch (Exception ignored) {}
                            return true;
                        }
                        if (Math.abs(event.getRawX() - downX) > dp(8) || Math.abs(event.getRawY() - downY) > dp(8)) {
                            handler.removeCallbacks(startDrag);
                        }
                        return false;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(startDrag);
                        boolean wasDragging = dragging;
                        dragging = false;
                        return wasDragging;
                }
                return false;
            }
        });
        try {
            windowManager.addView(floatingWeb, floatingParams);
            addFloatingHandle();
            floatingWeb.loadUrl("file:///android_asset/index.html");
        } catch (Exception e) {
            floatingWeb = null;
            Toast.makeText(this, "Could not open floating menu: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void addFloatingHandle() {
        if (floatingHandle != null) return;
        floatingHandle = new TextView(this);
        floatingHandle.setText("☰");
        floatingHandle.setTextColor(Color.WHITE);
        floatingHandle.setTextSize(20);
        floatingHandle.setGravity(Gravity.CENTER);
        floatingHandle.setBackgroundColor(Color.rgb(59, 130, 246));
        floatingHandle.setElevation(dp(8));
        floatingHandle.setOnClickListener(v -> {
            if (floatingWeb != null) floatingWeb.setVisibility(View.VISIBLE);
            if (floatingHandle != null) floatingHandle.setVisibility(View.GONE);
        });
        handleParams = new WindowManager.LayoutParams(dp(48), dp(48),
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        handleParams.gravity = Gravity.TOP | Gravity.END;
        handleParams.x = dp(10);
        handleParams.y = dp(100);
        try { windowManager.addView(floatingHandle, handleParams); }
        catch (Exception ignored) { floatingHandle = null; }
    }

    private void hideFloatingMenu() {
        if (floatingWeb != null) floatingWeb.setVisibility(View.GONE);
        if (floatingHandle != null) floatingHandle.setVisibility(View.VISIBLE);
    }

    private void closeFloatingMenu() {
        if (floatingHandle != null) {
            try { windowManager.removeView(floatingHandle); } catch (Exception ignored) {}
            floatingHandle = null;
            handleParams = null;
        }
        if (floatingWeb != null) {
            try { windowManager.removeView(floatingWeb); } catch (Exception ignored) {}
            floatingWeb.destroy();
            floatingWeb = null;
            floatingParams = null;
        }
    }

    private class OverlayBridge {
        private final boolean isFloating;
        OverlayBridge(boolean floating) { isFloating = floating; }

        @JavascriptInterface
        public boolean hasPermission() {
            return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(MainActivity.this);
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Appear on top permission is already enabled", Toast.LENGTH_SHORT).show();
                    showFloatingMenu();
                }
            });
        }

        @JavascriptInterface
        public boolean isFloating() {
            return floatingWeb != null;
        }

        @JavascriptInterface
        public void openOverlay() {
            runOnUiThread(() -> showFloatingMenu());
        }

        @JavascriptInterface
        public void closeOverlay() {
            runOnUiThread(() -> closeFloatingMenu());
        }

        @JavascriptInterface
        public void hideOverlay() {
            runOnUiThread(() -> hideFloatingMenu());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.post(() -> web.evaluateJavascript(
                "if(window.updateOverlayStatus) updateOverlayStatus();", null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_REQUEST && pending != null) {
            pending.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pending = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onDestroy() {
        closeFloatingMenu();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
