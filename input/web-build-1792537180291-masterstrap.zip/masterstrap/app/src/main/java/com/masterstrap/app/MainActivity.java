package com.masterstrap.app;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.graphics.Typeface;
import android.text.InputFilter;
import android.widget.SeekBar;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {
    static final int REQ_IMPORT = 11, REQ_EXPORT = 12;
    static final String ROOT_DIR_FMT = "/data/data/%s/files/ClientSettings"; // unverified; needs root

    int BG, CARD, TXT, SUB, LINE, SOFT;
    final int ACC = 0xFF1E9BF0, GOLD = 0xFFF2A81D;
    boolean dark;
    SharedPreferences sp;
    FrameLayout root, content;
    LinearLayout header, navRow;
    View nav, navInd, current;
    int selIdx = -1;
    final java.util.Map<String, View> cache = new java.util.HashMap<>();
    final List<LinearLayout> navItems = new ArrayList<>();
    final List<TextView> navTexts = new ArrayList<>();
    int tab = 0;
    String sub = null; // "editor", "settings", "mods"
    LaunchOverlay overlay;
    LinearLayout flagList;
    String flagFilter = "";
    final Handler h = new Handler(Looper.getMainLooper());

    // ------------------------------------------------------------ lifecycle
    @Override protected void onCreate(Bundle b) {
        sp = getSharedPreferences("ms", MODE_PRIVATE);
        dark = "Dark".equals(sp.getString("theme", "Light"));
        setTheme(dark ? android.R.style.Theme_Material_NoActionBar : android.R.style.Theme_Material_Light_NoActionBar);
        super.onCreate(b);
        BG = dark ? 0xFF0F141A : 0xFFEEF3F7;
        CARD = dark ? 0xFF1A222C : 0xFFFFFFFF;
        TXT = dark ? 0xFFF3F4F6 : 0xFF111827;
        SUB = dark ? 0xFF9CA3AF : 0xFF6B7280;
        LINE = dark ? 0xFF2C3744 : 0xFFD9DEE4;
        SOFT = dark ? 0xFF22394F : 0xFFDCEEFC;
        getWindow().setStatusBarColor(CARD);
        getWindow().setNavigationBarColor(BG);
        if (!dark) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        build();
        show();
    }

    @Override public void onBackPressed() {
        if (overlay != null) return;
        if (sub != null) {
            if ("mods".equals(sub)) tab = 1;
            sub = null;
            show();
        } else super.onBackPressed();
    }

    // ------------------------------------------------------------ helpers
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable rr(int fill, int r, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    LinearLayout vl() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setBackground(rr(CARD, 14, 0));
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        l.setElevation(dp(1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(12), dp(5), dp(12), dp(5));
        l.setLayoutParams(lp);
        return l;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    LinearLayout textBlock(String t, String d, boolean crown, boolean locked) {
        LinearLayout b = vl();
        LinearLayout tr = new LinearLayout(this);
        tr.setGravity(Gravity.CENTER_VERTICAL);
        tr.addView(tv(t, 15, locked ? SUB : TXT, true));
        if (crown) tr.addView(tv("  ♛", 13, GOLD, false));
        b.addView(tr);
        if (d != null) {
            TextView dd = tv(d, 12, SUB, false);
            dd.setPadding(0, dp(3), 0, 0);
            b.addView(dd);
        }
        return b;
    }

    View rowCard(LinearLayout text, View ctl, boolean locked) {
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        if (ctl != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.leftMargin = dp(10);
            c.addView(ctl, lp);
        }
        if (locked) c.setAlpha(.55f);
        return c;
    }

    Switch makeSwitch() {
        Switch sw = new Switch(this);
        int[][] st = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(st, new int[]{Color.WHITE, Color.WHITE}));
        sw.setTrackTintList(new ColorStateList(st, new int[]{ACC, 0xFFCBD2D9}));
        return sw;
    }

    View toggle(String t, String d, String key, boolean def, boolean locked) {
        Switch sw = makeSwitch();
        sw.setChecked(!locked && sp.getBoolean(key, def));
        View r = rowCard(textBlock(t, d, locked, locked), sw, locked);
        if (locked) {
            sw.setEnabled(false);
            sw.setClickable(false);
            r.setOnClickListener(v -> toast("Pro feature - needs a license key"));
        } else {
            sw.setOnCheckedChangeListener((v, c) -> {
                sp.edit().putBoolean(key, c).apply();
                if (c && key.equals("showfps")) ensureOverlayPermission();
            });
        }
        return r;
    }

    View toggle(String t, String d, String key, boolean def) { return toggle(t, d, key, def, false); }

    View drop(String t, String d, String key, String def, String[] opts, boolean crown) {
        TextView dd = tv(sp.getString(key, def) + "  ▾", 13, TXT, true);
        dd.setBackground(rr(CARD, 10, LINE));
        dd.setPadding(dp(12), dp(8), dp(12), dp(8));
        dd.setOnClickListener(v -> {
            PopupMenu pm = new PopupMenu(this, dd);
            for (String o : opts) pm.getMenu().add(o);
            pm.setOnMenuItemClickListener(it -> {
                String s = it.getTitle().toString();
                sp.edit().putString(key, s).apply();
                dd.setText(s + "  ▾");
                if (key.equals("theme")) recreate();
                return true;
            });
            pm.show();
        });
        return rowCard(textBlock(t, d, crown, false), dd, false);
    }

    TextView section(String t, boolean crown) {
        TextView s = tv(t + (crown ? "  ♛" : ""), 14, TXT, true);
        s.setPadding(dp(16), dp(16), dp(16), dp(4));
        return s;
    }

    TextView pageTitle(String t) {
        TextView s = tv(t, 18, TXT, true);
        s.setPadding(dp(16), dp(12), dp(16), dp(4));
        return s;
    }

    View navRow(String title, String desc, String glyph, View.OnClickListener click) {
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView g = tv(glyph, 22, SUB, false);
        g.setGravity(Gravity.CENTER);
        c.addView(g, new LinearLayout.LayoutParams(dp(40), -2));
        c.addView(textBlock(title, desc, false, false), new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv("→", 20, ACC, true));
        c.setOnClickListener(click);
        press(c);
        return c;
    }

    TextView pill(String t) {
        TextView b = tv(t, 13, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rr(ACC, 10, 0));
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        press(b);
        return b;
    }

    LinearLayout newPage() {
        LinearLayout p = vl();
        p.setPadding(0, 0, 0, dp(110));
        return p;
    }

    // ------------------------------------------------------------ shell
    void press(View view) {
        view.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new OvershootInterpolator(2.5f)).start();
            return false;
        });
    }

    void build() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        root.setFocusableInTouchMode(true);
        LinearLayout col = vl();

        header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(CARD);
        header.setPadding(dp(16), dp(10), dp(16), dp(10));
        header.setElevation(dp(2));
        header.addView(tv("\u25C8", 30, SUB, false), new LinearLayout.LayoutParams(dp(44), -2));
        LinearLayout names = vl();
        names.addView(tv("Masterstrap", 19, TXT, true));
        names.addView(tv("FastFlag & Game Boost", 12, SUB, false));
        header.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView gear = tv("\u2699", 24, SUB, false);
        gear.setPadding(dp(10), dp(4), dp(4), dp(4));
        gear.setOnClickListener(v -> { sub = "settings"; show(); });
        press(gear);
        header.addView(gear);
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));

        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout wrap = new FrameLayout(this);
        wrap.setBackground(rr(CARD, 32, 0));
        wrap.setElevation(dp(6));
        navInd = new View(this);
        navInd.setBackground(rr(SOFT, 22, 0));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(0, dp(50));
        ip.topMargin = dp(6);
        wrap.addView(navInd, ip);
        navRow = new LinearLayout(this);
        navRow.setGravity(Gravity.CENTER_VERTICAL);
        navRow.setPadding(dp(8), dp(6), dp(8), dp(6));
        wrap.addView(navRow, new FrameLayout.LayoutParams(-1, -1));
        String[] icons = {"\u2691", "\u2699", "\uD83C\uDFAE", "\u25C6"};
        String[] labels = {"FastFlag", "FF Settings", "Game Mode", "Preset"};
        for (int i = 0; i < 4; i++) {
            if (i == 2) navRow.addView(new View(this), new LinearLayout.LayoutParams(dp(64), 1));
            final int idx = i;
            LinearLayout it = vl();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(5), 0, dp(5));
            TextView ic = tv(icons[i], 18, SUB, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(labels[i], 10, SUB, true);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setOnClickListener(v -> { if (tab == idx && sub == null) return; tab = idx; sub = null; show(); });
            press(it);
            navItems.add(it);
            navTexts.add(ic);
            navTexts.add(lb);
            navRow.addView(it, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        nav = wrap;
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-1, dp(62));
        np.gravity = Gravity.BOTTOM;
        np.setMargins(dp(12), 0, dp(12), dp(12));
        root.addView(nav, np);

        RocketView rocket = new RocketView(this);
        GradientDrawable rb = new GradientDrawable();
        rb.setShape(GradientDrawable.OVAL);
        rb.setColor(CARD);
        rb.setStroke(dp(2), ACC);
        rocket.setBackground(rb);
        rocket.setElevation(dp(8));
        rocket.setOnClickListener(v -> startLaunch());
        press(rocket);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(60), dp(60));
        rp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        rp.bottomMargin = dp(22);
        root.addView(rocket, rp);
        ObjectAnimator bob = ObjectAnimator.ofFloat(rocket, "translationY", 0f, -dp(3));
        bob.setDuration(1500);
        bob.setRepeatMode(ObjectAnimator.REVERSE);
        bob.setRepeatCount(ObjectAnimator.INFINITE);
        bob.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        bob.start();
        setContentView(root);
    }

    void moveInd(final int idx, boolean anim) {
        final View it = navItems.get(idx);
        if (nav.getVisibility() != View.VISIBLE) return;
        if (it.getWidth() == 0) { navRow.post(() -> { if (it.getWidth() > 0) moveInd(idx, false); }); return; }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) navInd.getLayoutParams();
        if (lp.width != it.getWidth() || lp.height != it.getHeight()) {
            lp.width = it.getWidth();
            lp.height = it.getHeight();
            navInd.setLayoutParams(lp);
        }
        navInd.animate().cancel();
        float x = it.getLeft();
        if (anim) navInd.animate().translationX(x).setDuration(280).setInterpolator(new OvershootInterpolator(.9f)).start();
        else navInd.setTranslationX(x);
    }

    void select(int idx) {
        for (int i = 0; i < navItems.size(); i++) {
            int to = i == idx ? ACC : SUB;
            for (int k = 0; k < 2; k++) {
                TextView t = navTexts.get(i * 2 + k);
                if (selIdx == -1) t.setTextColor(to);
                else if (i == idx || i == selIdx) {
                    ObjectAnimator a = ObjectAnimator.ofArgb(t, "textColor", t.getCurrentTextColor(), to);
                    a.setDuration(220);
                    a.start();
                }
            }
        }
        moveInd(idx, selIdx != -1);
        selIdx = idx;
    }

    void swap(View page) {
        if (page == current) return;
        final View old = current;
        current = page;
        if (page.getParent() != null) ((ViewGroup) page.getParent()).removeView(page);
        page.animate().cancel();
        page.setAlpha(0f);
        page.setTranslationY(dp(14));
        content.addView(page, new FrameLayout.LayoutParams(-1, -1));
        page.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        if (old != null) {
            old.animate().cancel();
            old.animate().alpha(0f).setDuration(120).withEndAction(() -> {
                if (old != current && old.getParent() == content) content.removeView(old);
            }).start();
        }
    }

    void show() {
        boolean settings = "settings".equals(sub);
        header.setVisibility(settings ? View.GONE : View.VISIBLE);
        nav.setVisibility(settings ? View.GONE : View.VISIBLE);
        root.getChildAt(2).setVisibility(settings ? View.GONE : View.VISIBLE);
        String ck = sub == null ? "tab" + tab : null;
        View page;
        if (ck != null && cache.containsKey(ck)) {
            page = cache.get(ck);
        } else {
            LinearLayout p = newPage();
            if ("editor".equals(sub)) buildEditor(p);
            else if ("settings".equals(sub)) buildSettings(p);
            else if ("mods".equals(sub)) buildMods(p);
            else if (tab == 0) buildFastFlag(p);
            else if (tab == 1) buildFFSettings(p);
            else if (tab == 2) buildGameMode(p);
            else buildPreset(p);
            ScrollView sv = new ScrollView(this);
            sv.setVerticalScrollBarEnabled(false);
            sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
            sv.addView(p);
            page = sv;
            if (ck != null) cache.put(ck, sv);
        }
        swap(page);
        if (!settings) select(tab);
    }

    // ------------------------------------------------------------ pages
    View fpsRow() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(sp.getString("fps", "60"));
        et.setTextSize(14);
        et.setTypeface(null, Typeface.BOLD);
        et.setGravity(Gravity.CENTER);
        et.setSingleLine(true);
        et.setTextColor(TXT);
        et.setBackground(rr(CARD, 10, LINE));
        et.setPadding(dp(14), dp(8), dp(14), dp(8));
        et.setMinWidth(dp(76));
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        final Runnable commit = () -> {
            int n;
            try { n = Integer.parseInt(et.getText().toString().trim()); } catch (Exception e) { n = 60; }
            n = Math.max(30, Math.min(9999, n));
            et.setText(String.valueOf(n));
            sp.edit().putString("fps", String.valueOf(n)).apply();
        };
        et.setOnEditorActionListener((view, act, ev) -> {
            commit.run();
            et.clearFocus();
            root.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
            return true;
        });
        et.setOnFocusChangeListener((view, f) -> { if (!f) commit.run(); });
        return rowCard(textBlock("Target frame rate (Global)",
                "Enter the FPS target Masterstrap should request on the next launch (30–9999). Actual FPS still depends on the game, GPU and display driver.",
                true, false), et, false);
    }

    void buildFastFlag(LinearLayout p) {
        p.addView(navRow("FastFlag Editor", "Add, import or edit individual FastFlags", "⚑",
                v -> { sub = "editor"; show(); }));
        p.addView(toggle("Apply Roblox optimizations",
                "Applies your selected optimizations whenever you save and launch. Turn this off to start Roblox with its normal configuration.",
                "apply", true));
        p.addView(section("Graphics quality", false));
        p.addView(drop("Anti-aliasing quality (MSAA)", "Overrides Roblox MSAA with an Android-compatible FastFlag.",
                "msaa", "Automatic", new String[]{"Automatic", "1x", "2x", "4x"}, false));
        String[] frm = new String[22];
        frm[0] = "Automatic";
        for (int i = 1; i <= 21; i++) frm[i] = String.valueOf(i);
        p.addView(drop("FRM quality override", "Selects a fixed Roblox render-quality level from 1 to 21.",
                "frm", "Automatic", frm, false));
        p.addView(drop("Rendering mode",
                "Automatic lets Roblox choose. Vulkan and OpenGL pair an explicit FastFlag with the matching Android graphics API bridge for the next launch.",
                "render", "Automatic", new String[]{"Automatic", "Vulkan", "OpenGL"}, false));
        p.addView(drop("Dynamic render resolution",
                "Caps the internal 16:9 render pixel budget while keeping the Android UI at native size.",
                "dynres", "Automatic", new String[]{"Automatic", "50%", "75%", "100%"}, false));
        p.addView(section("Verified Roblox preferences", false));
        p.addView(toggle("Force lowest Roblox graphics", "Forces graphics to level 1 when you launch patched Roblox through Masterstrap. Turn off to choose the quality in Roblox; low quality may reduce shader effects. No root needed.", "lowest", false));
        p.addView(toggle("Reduce in-game motion", "Uses Roblox's native ReducedMotion setting to stop or reduce supported motion effects. Requires root.", "reducemotion", false));
        p.addView(toggle("In-game haptics", "Controls Roblox's native HapticStrength setting. Disable it to remove supported vibration feedback. Requires root.", "haptics", true));
        p.addView(section("Mobile performance", false));
        p.addView(fpsRow());
        p.addView(toggle("One-tap graphics boost", "Reduces anti-aliasing, visual effects and grass while optimizing 3D model memory to prioritize FPS.", "boost", true));
        p.addView(toggle("Reduce 3D model detail", "Uses simpler versions of distant 3D models to reduce graphics and memory load.", "reduce3d", false));
        p.addView(toggle("Reduce texture load", "Skips very high-resolution texture levels to reduce RAM and graphics-memory use.", "reducetex", false));
        p.addView(toggle("Optimize 3D model memory", "Automatically balances memory used for 3D models on Android devices.", "optmem", true));
        p.addView(toggle("Preload 3D models", "Loads 3D models earlier to reduce objects appearing late during gameplay.", "preload", true));
        p.addView(section("Rendering and visual effects", false));
        p.addView(toggle("Disable shadows", "Turns off most in-game shadows to reduce GPU load and improve performance, especially on lower-end devices.", "noshadow", false));
        p.addView(toggle("Reduce visual effects", "Removes bloom, blur, depth-of-field and similar effects to reduce GPU load.", "reducefx", false));
        p.addView(toggle("Remove grass", "Sets grass rendering distances to zero to reduce graphics work in outdoor scenes.", "nograss", false));
        p.addView(toggle("SkyGray", "Replaces the normal sky with a simple gray background for a cleaner, lighter scene.", "skygray", false));
        p.addView(toggle("Display FPS", "Enables Roblox's built-in FPS counter, plus a floating FPS overlay (needs \"Display over other apps\" and root).", "showfps", false));
        p.addView(section("Interface and camera", false));
        p.addView(toggle("Remove menu background blur", "Removes the blurred background behind Roblox menus for a clearer and slightly lighter interface.", "noblur", true));
    }

    void buildFFSettings(LinearLayout p) {
        p.addView(pageTitle("FastFlag Settings"));
        p.addView(navRow("Mods", "Customize shaders, stretch screen, in-game font & text size", "✨",
                v -> { sub = "mods"; show(); }));
        p.addView(section("Graphics & frame rate", false));
        p.addView(toggle("Stabilize frame rate", "Automatically reduces render resolution when the GPU is overloaded to help gameplay stay smooth.", "stabilize", true));
        p.addView(toggle("Lighter distant animations", "Simplifies character animations at a distance to reduce CPU load in crowded games.", "lightanim", true));
        p.addView(toggle("Adaptive graphics control", "Allows Roblox to adjust render resolution according to the device's available graphics performance.", "adaptive", true));
        p.addView(toggle("Respond to GPU load", "Uses actual GPU frame timing to adjust graphics more accurately when performance changes.", "gpuload", true));
        p.addView(section("Network", false));
        p.addView(toggle("Faster game asset loading", "Groups game asset requests to reduce repeated network work while joining and loading a game.", "assets", true));
        p.addView(toggle("Desync", "Increases network packet and physics send rates to minimize latency and optimize connection.", "desync", false, true));
        p.addView(toggle("Network latency reducer", "Reduces client-server packet replication delay for snappier real-time movement and lower hitbox latency.", "netlat", false, true));
        p.addView(toggle("Advanced hitreg fix", "Optimizes RakNet network loop, client prediction, and packet buffers to ensure accurate combat hit registration and eliminate ghost hits.", "hitreg", false, true));
        p.addView(section("Power & game session", false));
        p.addView(toggle("Reduce background battery use", "Lets Roblox cooperate with Android power management when the game is running in the background.", "battery", true));
        p.addView(section("Memory & assets", false));
        p.addView(toggle("Optimize 3D model memory", "Balances memory reserved for 3D models to reduce excessive RAM use on Android devices.", "optmem", true));
        p.addView(toggle("No Texture", "Removes terrain material textures for a simpler look and may reduce graphics load. Some games may look flat or unusual.", "notex", false));
        p.addView(toggle("NO VFX", "Turns off glowing, blur, and heavy visual effects to boost FPS and reduce lag on weaker devices. Note: may disable Shader Package lighting.", "novfx", false));
        p.addView(toggle("Faster repeated animations", "Keeps animation data ready in memory to avoid decoding the same animation repeatedly.", "fastanim", true));
        p.addView(section("Interface and camera", false));
        p.addView(toggle("Hide player names", "Hide default names above characters on the next Roblox launch. Does not hide chat, the player list or custom name tags made by a game.", "hidenames", false));
        p.addView(toggle("Remove menu background blur", "Removes the blurred background behind Roblox menus for a clearer and slightly lighter interface.", "noblur", true));
        p.addView(toggle("Adaptive 60Hz Physics (Faster Walk Speed)", "Forces physics to update at 60Hz to reduce friction and drag, allowing faster character movement. Note: Turn off Shift Lock for best effect.", "phys60", false, true));
    }

    // ---- Mods page building blocks
    LinearLayout group(String title) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.VERTICAL);
        c.addView(tv(title, 17, TXT, true));
        return c;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(14), 0, dp(14));
        d.setLayoutParams(lp);
        return d;
    }

    LinearLayout inlineHead(String title, String desc) {
        LinearLayout b = vl();
        b.setPadding(0, dp(12), 0, 0);
        b.addView(tv(title, 15, TXT, true));
        if (desc != null) {
            TextView d = tv(desc, 12, SUB, false);
            d.setPadding(0, dp(3), 0, dp(8));
            b.addView(d);
        }
        return b;
    }

    View inlineDrop(String title, String desc, String key, String def, String[] opts) {
        LinearLayout b = inlineHead(title, desc);
        final LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(rr(CARD, 10, LINE));
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        final TextView val = tv(sp.getString(key, def), 13, TXT, true);
        box.addView(val, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(tv("▾", 13, SUB, false));
        box.setOnClickListener(v -> {
            PopupMenu pm = new PopupMenu(this, box);
            for (String o : opts) pm.getMenu().add(o);
            pm.setOnMenuItemClickListener(it -> {
                String s = it.getTitle().toString();
                sp.edit().putString(key, s).apply();
                val.setText(s);
                return true;
            });
            pm.show();
        });
        press(box);
        b.addView(box);
        return b;
    }

    View inlineToggle(String title, String desc, String key, boolean def) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(0, dp(12), 0, 0);
        LinearLayout t = textBlock(title, desc, false, false);
        b.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = makeSwitch();
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, c) -> sp.edit().putBoolean(key, c).apply());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(10);
        b.addView(sw, lp);
        return b;
    }

    View inlineSlider(String title, String desc, String key, int min, int max, int def, String[] labels) {
        LinearLayout b = vl();
        b.setPadding(0, dp(12), 0, 0);
        LinearLayout tr = new LinearLayout(this);
        tr.setGravity(Gravity.CENTER_VERTICAL);
        tr.addView(tv(title, 15, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView chip = tv(sp.getInt(key, def) + "%", 11, ACC, true);
        chip.setBackground(rr(SOFT, 10, 0));
        chip.setPadding(dp(10), dp(3), dp(10), dp(3));
        tr.addView(chip);
        b.addView(tr);
        TextView d = tv(desc, 12, SUB, false);
        d.setPadding(0, dp(3), 0, dp(6));
        b.addView(d);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(sp.getInt(key, def) - min);
        sb.setProgressTintList(ColorStateList.valueOf(ACC));
        sb.setThumbTintList(ColorStateList.valueOf(ACC));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int pr, boolean user) {
                int v = pr + min;
                chip.setText(v + "%");
                sp.edit().putInt(key, v).apply();
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        b.addView(sb);
        LinearLayout lr = new LinearLayout(this);
        for (int i = 0; i < labels.length; i++) {
            TextView l = tv(labels[i], 10, SUB, false);
            l.setGravity(i == 0 ? Gravity.START : i == labels.length - 1 ? Gravity.END : Gravity.CENTER);
            lr.addView(l, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        b.addView(lr);
        return b;
    }

    void buildMods(LinearLayout p) {
        p.addView(backRow("Mods"));
        p.addView(section("Display & Graphics", false));
        LinearLayout g1 = group("Shaders & Lighting");
        g1.addView(inlineDrop("Shader Package (Atmosphere & Lighting)",
                "Choose lighting atmosphere and color style for the game world (Daytime 4K, Cyberpunk, Ghibli...).",
                "shader", "Original (Recommended)", new String[]{"Original (Recommended)", "Daytime 4K", "Cyberpunk", "Ghibli"}));
        g1.addView(divider());
        g1.addView(inlineToggle("Reflective Wet Floor", "Add glossy reflections and realistic light shines to ground surfaces around you.", "wetfloor", false));
        p.addView(g1);
        LinearLayout g2 = group("Display Ratio (Stretch Screen)");
        g2.removeAllViews();
        g2.addView(inlineSlider("Display Ratio (Stretch Screen)",
                "Adjust screen width: below 100% widens field of view (easier to spot enemies), above 100% narrows view (100% is default).",
                "stretchpct", 10, 200, 100, new String[]{"10% (Widest)", "100% (Default)", "200% (Narrowest)"}));
        p.addView(g2);
        LinearLayout g3 = group("In-Game Font & Size");
        g3.addView(inlineDrop("Font Style", "Change text style for in-game chat, player names and menus (Minecraft, Anime, Comic...).",
                "font", "Original (Default)", new String[]{"Original (Default)", "Minecraft Pixel (8-Bit Retro)", "Gotham Bold (Clean & Modern)",
                        "Michroma Sci-Fi (Futuristic Tech)", "Fredoka Cartoon (Cute & Chubby)", "Kalam Anime Hand (Manga Handwriting)",
                        "Bangers Comic (Action Pop)", "Special Typewriter (Vintage)", "Creepster Horror (Halloween Spooky)",
                        "Merriweather Serif (Classic Elegance)"}));
        g3.addView(divider());
        g3.addView(inlineSlider("Text Size", "Scale text size up or down for comfortable reading on phone screens.",
                "textpct", 50, 150, 100, new String[]{"50%", "75%", "100%", "125%", "150%"}));
        p.addView(g3);
    }

    void buildGameMode(LinearLayout p) {
        p.addView(pageTitle("Game Mode"));
        TextView s = tv("Safe Boost (Stability & Latency)", 14, TXT, true);
        s.setPadding(dp(20), dp(10), dp(16), dp(4));
        p.addView(s);
        p.addView(toggle("Free Masterstrap memory before launch", "Asks Android to reclaim unused memory from Masterstrap before Roblox opens. It affects only Masterstrap and never closes another app.", "freemem", true));
        p.addView(toggle("Use low-latency Wi-Fi while launching", "Temporarily asks Android for low-latency Wi-Fi while Roblox opens. It works only when the device is connected through Wi-Fi.", "lowwifi", true));
        p.addView(toggle("Keep the CPU awake while Roblox starts", "Prevents the processor from sleeping for up to 60 seconds while Roblox starts. It does not overclock or change the CPU speed.", "cpuawake", true));
        p.addView(toggle("Pause launch boosts when the device is too hot", "Checks Android's temperature status before launch. If severe heat is detected, Wi-Fi and CPU launch boosts are skipped until the device cools down.", "thermal", true));
        p.addView(toggle("Keep Masterstrap running in the background", "Shows a small notification so Android doesn't close Masterstrap while Roblox is open. Stop it any time from the notification or Settings.", "bgrun", true));
        p.addView(section("Turbo Boost", true));
        p.addView(toggle("Enable Game Mode", "Activates a one-shot native performance profile only when Roblox is launched from Masterstrap.", "t1", false, true));
        p.addView(toggle("Android Adaptive Performance", "Lets Roblox report loading, gameplay and measured CPU work to Android so the scheduler can allocate performance without root.", "t2", false, true));
        p.addView(toggle("CPU Performance Priority", "Prefers the fastest available CPU cluster for critical Roblox threads when supported.", "t3", false, true));
        p.addView(toggle("Smart RAM Cleanup", "Performs one measured native-heap trim after startup; never runs a periodic cleaner.", "t4", false, true));
        p.addView(toggle("Faster Game Launch", "Removes the launch animation and warms mapped Roblox code pages once at startup.", "t5", false, true));
        p.addView(toggle("Keep Display Active", "Requests a session-scoped screen wake lock from inside Roblox.", "t6", false, true));
        p.addView(toggle("Unrestricted Power", "Keeps the Roblox CPU awake during the session; Android thermal limits still apply.", "t7", false, true));
        p.addView(toggle("Full-session Low-latency Wi-Fi", "Requests Android low-latency Wi-Fi from the foreground Roblox process and automatically becomes inactive when Roblox leaves the foreground.", "t8", false, true));
        p.addView(toggle("Sustained Performance Guard", "Monitors Android thermal status during startup and reduces performance hints before heat causes severe throttling.", "t9", false, true));
        p.addView(toggle("Adaptive Display Refresh", "Requests the closest seamless display refresh rate directly from the active Roblox surface. This complements the Roblox FPS target without forcing an unsupported Hz mode.", "t10", false, true));
        p.addView(toggle("Long-session Stability", "Uses Android Sustained Performance Mode on supported devices to trade a small amount of peak speed for steadier performance during long sessions.", "t11", false, true));
    }

    static final String[] POPULAR = {"Blox Fruits", "The Strongest Battleground", "Rivals", "Volleyball Legends", "Blade Ball"};
    static final String[] HOT = {"Basketball Legends", "Bedwars", "Blue Lock Rivals", "Boxing Beta", "CVR", "Jujutsu Shenanigans",
            "Murder Mystery 2", "NFL Universe FootBall", "Pure Soccer", "Timebomb Duels", "Touch Football", "TPS Street Soccer", "Volleyball 4.2"};
    static final int[] TILE = {0xFFE4572E, 0xFF7B4DD6, 0xFF2D9CDB, 0xFFF2994A, 0xFFEB5757, 0xFF27AE60, 0xFF9B51E0, 0xFF219653,
            0xFFD35400, 0xFF2F80ED, 0xFFC0392B, 0xFF16A085, 0xFFF39C12, 0xFF34495E, 0xFF8E44AD, 0xFF1ABC9C, 0xFFE67E22, 0xFF2980B9};

    void buildPreset(LinearLayout p) {
        p.addView(pageTitle("Preset"));
        p.addView(section("Popular", true));
        int n = 0;
        for (String g : POPULAR) p.addView(presetRow(g, true, TILE[n++ % TILE.length]));
        p.addView(section("Hot", false));
        for (String g : HOT) p.addView(presetRow(g, false, TILE[n++ % TILE.length]));
    }

    View presetRow(String game, boolean crown, int color) {
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView tile = tv(game.substring(0, 1), 18, Color.WHITE, true);
        tile.setGravity(Gravity.CENTER);
        tile.setBackground(rr(color, 10, 0));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(44), dp(44));
        tp.rightMargin = dp(12);
        c.addView(tile, tp);
        c.addView(tv(game, 15, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (crown) {
            TextView cr = tv("♛", 14, GOLD, false);
            cr.setPadding(0, 0, dp(10), 0);
            c.addView(cr);
        }
        TextView boost = pill("Boost");
        boost.setOnClickListener(v -> {
            sp.edit().putBoolean("boost", true).putBoolean("reduce3d", true).putBoolean("reducetex", true)
                    .putBoolean("stabilize", true).putBoolean("adaptive", true).putBoolean("optmem", true)
                    .putString("fps", "60").putString("preset", game).apply();
            cache.clear();
            toast("Boost profile applied for " + game + ". Tap the rocket to launch.");
        });
        c.addView(boost);
        return c;
    }

    View backRow(String title) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(14), dp(14), dp(6));
        TextView back = tv("‹ Back", 15, ACC, true);
        back.setPadding(0, 0, dp(14), 0);
        back.setOnClickListener(v -> {
            if ("mods".equals(sub)) { sub = null; tab = 1; } else sub = null;
            show();
        });
        r.addView(back);
        r.addView(tv(title, 17, TXT, true));
        return r;
    }

    // ------------------------------------------------------------ FastFlag editor
    JSONObject userFlags() {
        try { return new JSONObject(sp.getString("userflags", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    void saveFlags(JSONObject o) { sp.edit().putString("userflags", o.toString()).apply(); }

    void buildEditor(LinearLayout p) {
        p.addView(backRow("FastFlag Editor"));
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(12), dp(6), dp(12), dp(6));
        String[] names = {"+ Add", "Import JSON", "Export JSON", "Clear All"};
        for (int i = 0; i < 4; i++) {
            TextView b = pill(names[i]);
            b.setTextSize(12);
            b.setPadding(dp(6), dp(10), dp(6), dp(10));
            final int idx = i;
            b.setOnClickListener(v -> editorAction(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            bar.addView(b, lp);
        }
        p.addView(bar);
        EditText search = new EditText(this);
        search.setHint("Search flags (e.g. FFlagDebug, FPS)...");
        search.setTextSize(13);
        search.setSingleLine(true);
        search.setTextColor(TXT);
        search.setHintTextColor(SUB);
        search.setBackground(rr(CARD, 10, 0));
        search.setPadding(dp(14), dp(12), dp(14), dp(12));
        search.setText(flagFilter);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.setMargins(dp(14), dp(6), dp(14), dp(6));
        p.addView(search, sl);
        flagList = vl();
        p.addView(flagList);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { flagFilter = e.toString(); fillFlags(); }
        });
        fillFlags();
    }

    void fillFlags() {
        flagList.removeAllViews();
        JSONObject o = userFlags();
        Iterator<String> it = o.keys();
        List<String> keys = new ArrayList<>();
        while (it.hasNext()) keys.add(it.next());
        java.util.Collections.sort(keys);
        int shown = 0;
        for (String k : keys) {
            if (!flagFilter.isEmpty() && !k.toLowerCase().contains(flagFilter.toLowerCase())) continue;
            final String val = o.optString(k);
            LinearLayout c = card();
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.addView(textBlock(k, val, false, false), new LinearLayout.LayoutParams(0, -2, 1f));
            c.setOnClickListener(v -> editFlag(k, val));
            press(c);
            flagList.addView(c);
            shown++;
        }
        if (shown == 0) {
            TextView e = tv(keys.isEmpty() ? "No FastFlags yet. Tap + Add or Import JSON." : "No flags match your search.", 13, SUB, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(dp(16), dp(30), dp(16), dp(30));
            flagList.addView(e);
        }
    }

    void editFlag(String key, String val) {
        EditText et = new EditText(this);
        et.setText(val);
        et.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle(key).setView(et)
                .setPositiveButton("Save", (d, w) -> {
                    JSONObject o = userFlags();
                    try { o.put(key, et.getText().toString().trim()); } catch (Exception ignored) {}
                    saveFlags(o);
                    fillFlags();
                })
                .setNeutralButton("Delete", (d, w) -> { JSONObject o = userFlags(); o.remove(key); saveFlags(o); fillFlags(); })
                .setNegativeButton("Cancel", null).show();
    }

    void editorAction(int i) {
        if (i == 0) {
            EditText et = new EditText(this);
            et.setHint("Paste flag name or JSON snippet here...\nExample:\n{\n  \"FFlagDebugDisplayFPS\": \"True\"\n}");
            et.setTextSize(13);
            et.setMinLines(5);
            et.setGravity(Gravity.TOP);
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            new AlertDialog.Builder(this).setTitle("Add FastFlag").setView(et)
                    .setPositiveButton("Apply", (d, w) -> addFlags(et.getText().toString()))
                    .setNegativeButton("Cancel", null).show();
        } else if (i == 1) {
            Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            in.addCategory(Intent.CATEGORY_OPENABLE);
            in.setType("*/*");
            startActivityForResult(in, REQ_IMPORT);
        } else if (i == 2) {
            Intent in = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            in.addCategory(Intent.CATEGORY_OPENABLE);
            in.setType("application/json");
            in.putExtra(Intent.EXTRA_TITLE, "masterstrap_flags.json");
            startActivityForResult(in, REQ_EXPORT);
        } else {
            new AlertDialog.Builder(this).setTitle("Clear all FastFlags?")
                    .setPositiveButton("Clear", (d, w) -> { saveFlags(new JSONObject()); fillFlags(); })
                    .setNegativeButton("Cancel", null).show();
        }
    }

    void addFlags(String text) {
        text = text.trim();
        if (text.isEmpty()) return;
        JSONObject o = userFlags();
        try {
            if (text.startsWith("{")) {
                JSONObject in = new JSONObject(text);
                Iterator<String> it = in.keys();
                while (it.hasNext()) { String k = it.next(); o.put(k, String.valueOf(in.get(k))); }
            } else {
                String[] kv = text.split("[:=]", 2);
                String k = kv[0].replace("\"", "").replace(",", "").trim();
                String v = kv.length > 1 ? kv[1].replace("\"", "").replace(",", "").trim() : "True";
                if (k.isEmpty()) throw new Exception();
                o.put(k, v);
            }
            saveFlags(o);
            fillFlags();
        } catch (Exception e) {
            toast("Couldn't read that flag. Use a name or a JSON object.");
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_IMPORT) {
                InputStream in = getContentResolver().openInputStream(u);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                addFlags(bo.toString("UTF-8"));
            } else if (req == REQ_EXPORT) {
                OutputStream out = getContentResolver().openOutputStream(u);
                out.write(userFlags().toString(2).getBytes("UTF-8"));
                out.close();
                toast("Exported");
            }
        } catch (Exception e) {
            toast("File error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ settings & about
    void buildSettings(LinearLayout p) {
        p.addView(backRow("Settings & About"));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), dp(8), dp(18), dp(12));
        top.addView(tv("◈", 40, SUB, false), new LinearLayout.LayoutParams(dp(56), -2));
        LinearLayout nm = vl();
        nm.addView(tv("Masterstrap v1.3.1", 20, TXT, true));
        nm.addView(tv("FastFlag & Game Boost", 12, SUB, false));
        top.addView(nm);
        p.addView(top);
        String last = sp.getString("lastapply", null);
        LinearLayout st = card();
        st.setOrientation(LinearLayout.VERTICAL);
        st.addView(tv("FastFlag apply status", 15, TXT, true));
        TextView stt = tv(last == null ? "No launch yet. Tap the rocket to apply your flags and start Roblox."
                : last.startsWith("OK") ? "Last launch: flags written through root.\n" + last.substring(2).trim()
                : "Last launch: NOT applied - " + explain(last), 12, last != null && last.startsWith("OK") ? ACC : SUB, false);
        stt.setPadding(0, dp(4), 0, 0);
        st.addView(stt);
        p.addView(st);
        p.addView(section("Preferences", false));
        p.addView(drop("App Theme", "Dark or Light visual style", "theme", "Light", new String[]{"Light", "Dark"}, false));
        p.addView(drop("Language", "App display language", "lang", "English", new String[]{"English"}, false));
        p.addView(drop("Preferred Roblox app", "Select which Roblox app to use and launch", "robloxapp", "Global", new String[]{"Global", "VNG"}, false));
        p.addView(section("Background", false));
        p.addView(navRow("Allow unrestricted battery use", "Stops Android from putting Masterstrap to sleep", "\u26A1", v -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception e2) { toast("Open battery settings manually"); }
            }
        }));
        p.addView(navRow("Stop background session", "Ends the notification and releases all boosts", "\u25A0", v -> {
            stopService(new Intent(this, BoostService.class));
            toast("Background session stopped");
        }));
        p.addView(section("Official Channels & Links", false));
        p.addView(navRow("GitHub Repository", "github.com/Masterstrap/Masterstrap-Android", "⬢", v -> open("https://github.com/Masterstrap/Masterstrap-Android")));
        p.addView(navRow("App User Guide →", "youtube.com/@Dank1ngs", "▶", v -> open("https://youtube.com/@Dank1ngs")));
        p.addView(navRow("Discord Community", "discord.gg/masterstrap", "●", v -> open("https://discord.gg/masterstrap")));
        p.addView(navRow("MIT License", "MIT License © 2026 Masterstrap Team", "⚙", v -> open("https://opensource.org/license/mit")));
        p.addView(section("License Key", false));
        LinearLayout c = card();
        c.setOrientation(LinearLayout.VERTICAL);
        LinearLayout tr = new LinearLayout(this);
        tr.setGravity(Gravity.CENTER_VERTICAL);
        tr.addView(tv("License Key", 15, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView chip = tv("Free Plan", 11, ACC, true);
        chip.setBackground(rr(CARD, 8, ACC));
        chip.setPadding(dp(8), dp(3), dp(8), dp(3));
        tr.addView(chip);
        c.addView(tr);
        c.addView(tv("Enter your license key to unlock full features & bypass ads.", 12, SUB, false));
        LinearLayout kr = new LinearLayout(this);
        kr.setGravity(Gravity.CENTER_VERTICAL);
        kr.setPadding(0, dp(8), 0, 0);
        EditText key = new EditText(this);
        key.setHint("License key");
        key.setTextSize(13);
        key.setSingleLine(true);
        key.setTextColor(TXT);
        key.setHintTextColor(SUB);
        kr.addView(key, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView act = pill("Activate");
        act.setOnClickListener(v -> toast("License activation isn't available in this build."));
        kr.addView(act);
        c.addView(kr);
        p.addView(c);
    }

    void ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) return;
        toast("Allow \"Display over other apps\" so the FPS counter can show on top of Roblox.");
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {}
    }

    void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { toast("No app can open this link"); }
    }

    // ------------------------------------------------------------ launch
    JSONObject computeFlags() {
        JSONObject o = new JSONObject();
        try {
            if (sp.getBoolean("apply", true)) {
                o.put("DFIntTaskSchedulerTargetFps", sp.getString("fps", "60"));
                String m = sp.getString("msaa", "Automatic");
                if (!m.equals("Automatic")) o.put("FIntDebugForceMSAASamples", m.substring(0, 1));
                String f = sp.getString("frm", "Automatic");
                if (!f.equals("Automatic")) o.put("DFIntDebugFRMQualityLevelOverride", f);
                else if (sp.getBoolean("lowest", false)) o.put("DFIntDebugFRMQualityLevelOverride", "1");
                String r = sp.getString("render", "Automatic");
                if (r.equals("Vulkan")) o.put("FFlagDebugGraphicsPreferVulkan", "True");
                if (r.equals("OpenGL")) o.put("FFlagDebugGraphicsPreferOpenGL", "True");
                if (sp.getBoolean("noshadow", false)) o.put("FIntRenderShadowIntensity", "0");
                if (sp.getBoolean("novfx", false) || sp.getBoolean("reducefx", false)) o.put("FFlagDisablePostFx", "True");
                if (sp.getBoolean("nograss", false)) { o.put("FIntFRMMinGrassDistance", "0"); o.put("FIntFRMMaxGrassDistance", "0"); }
                if (sp.getBoolean("skygray", false)) o.put("FFlagDebugSkyGray", "True");
                if (sp.getBoolean("showfps", false)) o.put("FFlagDebugDisplayFPS", "True");
                if (sp.getBoolean("notex", false)) {
                    o.put("DFFlagTextureQualityOverrideEnabled", "True");
                    o.put("DFIntTextureQualityOverride", "0");
                } else if (sp.getBoolean("reducetex", false)) {
                    o.put("DFFlagTextureQualityOverrideEnabled", "True");
                    o.put("DFIntTextureQualityOverride", "1");
                }
            }
            JSONObject u = userFlags();
            Iterator<String> it = u.keys();
            while (it.hasNext()) { String k = it.next(); o.put(k, u.get(k)); }
        } catch (Exception ignored) {}
        return o;
    }

    String robloxPackage() {
        return "VNG".equals(sp.getString("robloxapp", "Global")) ? "com.roblox.client.vnggames" : "com.roblox.client";
    }

    void startLaunch() {
        if (overlay != null) return;
        final String pkg = robloxPackage();
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) { toast("Roblox isn't installed (" + pkg + ")"); return; }
        overlay = new LaunchOverlay(this);
        overlay.setAlpha(0f);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        overlay.setElevation(dp(20));
        overlay.animate().alpha(1f).setDuration(250).start();
        final LaunchOverlay ov = overlay;
        final String flagsJson;
        try { flagsJson = computeFlags().toString(2); } catch (Exception e) { return; }

        boolean hot = false;
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        try {
            if (sp.getBoolean("thermal", true) && Build.VERSION.SDK_INT >= 29 && pm.getCurrentThermalStatus() >= PowerManager.THERMAL_STATUS_SEVERE) hot = true;
        } catch (Throwable ignored) {}
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 5);
        try {
            startForegroundService(new Intent(this, BoostService.class)
                    .putExtra("hot", hot)
                    .putExtra("bg", sp.getBoolean("bgrun", true))
                    .putExtra("cpuawake", sp.getBoolean("cpuawake", true))
                    .putExtra("lowwifi", sp.getBoolean("lowwifi", true))
                    .putExtra("fps", sp.getBoolean("showfps", false))
                    .putExtra("pkg", pkg));
        } catch (Throwable t) {
            safeBoosts(pm);
        }
        try { if (sp.getBoolean("freemem", true)) System.gc(); } catch (Throwable ignored) {}

        final long t0 = android.os.SystemClock.uptimeMillis();
        new Thread(() -> {
            final String res = writeFlags(flagsJson);
            h.post(() -> finishLaunch(ov, li, res, t0));
        }).start();
    }

    void finishLaunch(final LaunchOverlay ov, final Intent li, String res, long t0) {
        sp.edit().putString("lastapply", res).apply();
        boolean ok = res.startsWith("OK");
        ov.setMessage(ok ? "Flags applied. Launching Roblox..." : "Launching Roblox...");
        if (!ok) Toast.makeText(this, "FastFlags NOT applied: " + explain(res), Toast.LENGTH_LONG).show();
        long wait = Math.max(0, 1500 - (android.os.SystemClock.uptimeMillis() - t0));
        h.postDelayed(ov::launch, wait);
        h.postDelayed(() -> {
            try { startActivity(li); } catch (Exception e) { toast("Couldn't start Roblox"); }
            ov.animate().alpha(0f).setDuration(300).withEndAction(() -> {
                root.removeView(ov);
                if (overlay == ov) overlay = null;
            }).start();
        }, wait + 1100);
    }

    String explain(String res) {
        if (res.startsWith("OK")) return "Applied through root.";
        if (res.startsWith("NOROOT")) return "no root access. Android does not let apps edit Roblox's files without root.";
        if (res.startsWith("NODATA")) return "couldn't find Roblox's data folder.";
        return "write failed (" + res + ")";
    }

    void safeBoosts(PowerManager pm) {
        try { if (sp.getBoolean("freemem", true)) System.gc(); } catch (Throwable ignored) {}
        try {
            if (sp.getBoolean("cpuawake", true)) {
                PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "masterstrap:launch");
                wl.acquire(60000);
            }
        } catch (Throwable ignored) {}
        try {
            if (sp.getBoolean("lowwifi", true)) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                final WifiManager.WifiLock lock = wm.createWifiLock(mode, "masterstrap:wifi");
                lock.acquire();
                h.postDelayed(() -> { try { if (lock.isHeld()) lock.release(); } catch (Throwable ignored) {} }, 60000);
            }
        } catch (Throwable ignored) {}
    }

    /** Runs a command as root. Returns its output, or null if root is unavailable or the command failed. */
    String su(String cmd) {
        try {
            Process pr = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            InputStream in = pr.getInputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            if (!pr.waitFor(15, java.util.concurrent.TimeUnit.SECONDS)) { pr.destroy(); return null; }
            return pr.exitValue() == 0 ? bo.toString("UTF-8").trim() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Saves the generated JSON in app storage, then copies it into Roblox with root. Returns "OK ..." or an error code. */
    String writeFlags(String json) {
        try {
            File f = new File(getFilesDir(), "ClientAppSettings.json");
            FileOutputStream o = new FileOutputStream(f);
            o.write(json.getBytes("UTF-8"));
            o.close();
            f.setReadable(true, false);
            String pkg = robloxPackage();
            String id = su("id -u");
            if (id == null || !id.endsWith("0")) return "NOROOT";
            String base = "/data/data/" + pkg;
            String uid = su("stat -c %u " + base);
            if (uid == null || uid.isEmpty()) return "NODATA";
            su("am force-stop " + pkg);
            StringBuilder where = new StringBuilder();
            String[] dirs = {base + "/files/ClientSettings", base + "/files/exe/ClientSettings"};
            for (String d : dirs) {
                String dst = d + "/ClientAppSettings.json";
                su("mkdir -p " + d + " && cp " + f.getAbsolutePath() + " " + dst
                        + " && chmod 660 " + dst + " && chown -R " + uid + ":" + uid + " " + d
                        + " && (restorecon -R " + d + " || true)");
                String size = su("wc -c < " + dst);
                if (size != null && !size.trim().equals("0")) where.append(d).append(' ');
            }
            if (where.length() == 0) return "COPYFAIL";
            return "OK " + where.toString().trim();
        } catch (Throwable t) {
            return "ERR " + t.getClass().getSimpleName();
        }
    }
}
