package com.masterstrap.app;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

class RocketView extends View {
    RocketView(Context c) { super(c); }

    @Override protected void onDraw(Canvas canvas) {
        float s = Math.min(getWidth(), getHeight()) / 2.6f;
        Rocket.draw(canvas, getWidth() / 2f, getHeight() / 2f - s * 0.05f, s, false);
    }
}
